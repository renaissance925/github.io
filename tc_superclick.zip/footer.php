<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Superclick
 */

$theme_options = superclick_theme_options();
?>
		</div>
	</div><!-- #content -->

	<footer id="colophon" class="site-footer" role="contentinfo">
		
		<?php get_sidebar('footer'); ?>

		<div class="site-info">
			<div class="inner">
				<div class="left-path col-xs-6 col-sm-6 col-md-6 col-lg-6">
					<?php superclick_footer_copyright(); ?>
				</div>

				<?php if ( has_nav_menu( 'superclick-footer' ) ) : ?>
					<div class="right-path smenu default-menu col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<?php wp_nav_menu( array('theme_location' => 'superclick-footer', 'container' => false, 'menu_class' => 'menu') ); ?>
					</div>
				<?php endif; ?>

			</div><!-- .site-info -->
		</div>

	</footer><!-- #colophon -->
</div><!-- #page -->

<!-- Back To Top -->
<?php if( $theme_options['back_to_top'] == 1 ) : ?>
	<span class="back-to-top">
		<i class="fa fa-angle-double-up"></i>
	</span>
<?php endif; ?>

<?php wp_footer(); ?>

</body>
</html>
