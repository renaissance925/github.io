<?php
$theme_options = superclick_theme_options();

if ( $theme_options['footer_widget_col'] == 'four-col' ) :
?>
    <?php if ( is_active_sidebar( 'superclick-footer-one' ) || is_active_sidebar( 'superclick-footer-two' ) || is_active_sidebar( 'superclick-footer-three' )  ) : ?>
        <div class="site-inner-footer">
            <div class="footer-widget fwidget inner clearfix">
                
                <?php if ( is_active_sidebar( 'superclick-footer-one' )) : ?>
                    <div class="footer-sec col-xs-12 col-sm-3 col-md-3 col-lg-3">
                        <?php dynamic_sidebar( 'superclick-footer-one' ); ?>
                    </div>
                <?php endif; ?>
                
                <?php if ( is_active_sidebar( 'superclick-footer-two' )) : ?>
                    <div class="footer-sec col-xs-12 col-sm-3 col-md-3 col-lg-3">
                        <?php dynamic_sidebar( 'superclick-footer-two' ); ?>
                    </div>
                <?php endif; ?>

                <?php if ( is_active_sidebar( 'superclick-footer-three' )) : ?>
                    <div class="footer-sec col-xs-12 col-sm-3 col-md-3 col-lg-3">
                        <?php dynamic_sidebar( 'superclick-footer-three' ); ?>
                    </div>
                <?php endif; ?>

                <?php if ( is_active_sidebar( 'superclick-footer-four' )) : ?>
                    <div class="footer-sec col-xs-12 col-sm-3 col-md-3 col-lg-3">
                        <?php dynamic_sidebar( 'superclick-footer-four' ); ?>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php if ( $theme_options['footer_widget_col'] == 'three-col' ) :
?>
    <?php if ( is_active_sidebar( 'superclick-footer-one' ) || is_active_sidebar( 'superclick-footer-two' ) || is_active_sidebar( 'superclick-footer-three' )  ) : ?>
        <div class="site-inner-footer">
            <div class="footer-widget fwidget inner clearfix">
                
                <?php if ( is_active_sidebar( 'superclick-footer-one' )) : ?>
                    <div class="footer-sec col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <?php dynamic_sidebar( 'superclick-footer-one' ); ?>
                    </div>
                <?php endif; ?>
                
                <?php if ( is_active_sidebar( 'superclick-footer-two' )) : ?>
                    <div class="footer-sec col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <?php dynamic_sidebar( 'superclick-footer-two' ); ?>
                    </div>
                <?php endif; ?>

                <?php if ( is_active_sidebar( 'superclick-footer-three' )) : ?>
                    <div class="footer-sec col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <?php dynamic_sidebar( 'superclick-footer-three' ); ?>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php if ( $theme_options['footer_widget_col'] == 'two-col' ) : ?>
    <?php if ( is_active_sidebar( 'superclick-footer-one' ) || is_active_sidebar( 'superclick-footer-two' ) ) : ?>
        <div class="site-inner-footer">
            <div class="footer-widget fwidget inner clearfix">
                
                <?php if ( is_active_sidebar( 'superclick-footer-one' )) : ?>
                    <div class="footer-sec col-xs-12 col-sm-6 col-md-6 col-lg-6">
                        <?php dynamic_sidebar( 'superclick-footer-one' ); ?>
                    </div>
                <?php endif; ?>
                
                <?php if ( is_active_sidebar( 'superclick-footer-two' )) : ?>
                    <div class="footer-sec col-xs-12 col-sm-6 col-md-6 col-lg-6">
                        <?php dynamic_sidebar( 'superclick-footer-two' ); ?>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php if ( $theme_options['footer_widget_col'] == 'one-col' ) : ?>
    <?php if ( is_active_sidebar( 'superclick-footer-one' ) || is_active_sidebar( 'superclick-footer-two' ) ) : ?>
        <div class="site-inner-footer">
            <div class="footer-widget fwidget inner clearfix">
                
                <?php if ( is_active_sidebar( 'superclick-footer-one' )) : ?>
                    <div class="footer-sec col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <?php dynamic_sidebar( 'superclick-footer-one' ); ?>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>