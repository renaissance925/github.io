<?php
/**
 * The header for our theme.
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Superclick
 */

$theme_options = superclick_theme_options();

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#main"><?php esc_html_e( 'Skip to content', 'customizer' ); ?></a>

<?php if ( $theme_options['custom_super_click_layout'] == 'default-layout' ) : ?>
	<header id="masthead" class="tc-first-style site-header" role="banner">
		<?php if ( has_nav_menu( 'superclick-top' ) ) : ?>
			<div class="header-section clearfix">
				<div class="inner clearfix">
					<div class="site-headline">

						<?php if ( has_nav_menu( 'superclick-top' ) ) : ?>
							<div class="top-menu primary-navigation default-menu col-xs-12 col-sm-9 col-md-9 col-lg-9"> <!-- Top MENU -->

								<?php wp_nav_menu( array('theme_location' => 'superclick-top', 'container' => false, 'menu_class' => 'menu nav clearfix') ); ?>
							
							</div><!-- ./Top MENU -->
						<?php endif; ?>

						<form role="search" method="get" class="search-box col-xs-12 col-sm-3 col-md-3 col-lg-3" action="<?php echo esc_url( home_url( '/' ) ); ?>" _lpchecked="1">
					    	<label for="search-input">
					    		<i class="fa fa-search" aria-hidden="true"></i>
					    		<span class="sr-only">Search icons</span>
					    	</label>
					    	
					    	<input id="search-input" class="input-control" name="s" id="s" value="<?php echo get_search_query(); ?>" placeholder="<?php esc_html_e('Search ...', 'superclick'); ?>" />
					    	<a id="search-clear" href="#" class="fa fa-times-circle hide" aria-hidden="true">
					    		<span class="sr-only">Clear search</span>
					    	</a>
					    </form>

					</div>
				</div>
			</div>
		<?php endif; ?>

		<div class="inner">
			<div class="site-branding site-branding col-xs-12 col-sm-4 col-md-3 col-lg-3">

				<?php superclick_header_title(); ?>

			</div><!-- .site-branding -->

			<!-- Header Ads -->
			<?php 
				if ( is_active_sidebar( 'superclick-header-ad' )) :
				?>
					
					<div class="header-widget col-xs-12 col-sm-8 col-md-9 col-lg-9">
						
						<?php dynamic_sidebar( 'superclick-header-ad' ); ?>
					
					</div>

				<?php
				endif;
			?>
		</div>

		<?php if ( has_nav_menu( 'superclick-primary' ) ) : ?>
			<nav <?php if ( 1 == $theme_options['sticky_header'] ) : ?>id="sticky"<?php endif; ?> class="secondary-menu main-navigation clearfix" role="navigation">
				
				<div class="inner">
					<div class="navbar-header"> 
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse"> 
							<span class="sr-only"><?php esc_html_e( 'Toggle Navigation', 'superclick' ); ?></span> 
							<span class="icon-bar"></span> 
							<span class="icon-bar"></span> 
							<span class="icon-bar"></span> 
						</button>
						<a class="navbar-brand" href="#"><?php esc_html_e( 'Menu', 'superclick' ); ?></a>
					</div>
					<div class="menu-container">
						<?php wp_nav_menu( array( 'theme_location' => 'superclick-primary', 'menu_id' => 'menu navbar-nav' ) ); ?>
					</div>
				</div>
			</nav><!-- #site-navigation -->

		<?php endif; ?>
		<div id="catcher" ></div>
	</header><!-- #masthead -->

<?php else : ?>
	
	<header id="masthead" class="site-header" role="banner">
		
		<div class="top-header">
			<div class="inner clearfix">
				<!-- Header Ads -->
				<?php 
					if ( is_active_sidebar( 'superclick-header-ad' )) :
					?>
						
						<div class="top-banner clearfix">
							
							<?php dynamic_sidebar( 'superclick-header-ad' ); ?>
						
						</div>

					<?php
					endif;
				?>
			</div>
		</div>

		<div <?php if ( 1 == $theme_options['sticky_header'] ) : ?>id="sticky"<?php endif; ?> class="tc-second-style bottom-header">
			<div class="inner">
				<div class="site-branding col-xs-6 col-sm-6 col-md-4 col-lg-4">

					<?php superclick_header_title(); ?>

				</div><!-- .site-branding -->

				<?php if ( has_nav_menu( 'superclick-primary' ) ) : ?>
					
					<nav class="secondary-menu main-navigation" role="navigation">

						<div class="navbar-header">

							<a class="navbar-brand" href="#">Menu</a>
							
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
								<span class="sr-only"><?php esc_html_e( 'Toggle Navigation', 'superclick' ); ?></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						
						<?php wp_nav_menu( array( 'theme_location' => 'superclick-primary', 'menu_id' => 'primary-menu menu navbar-nav' ) ); ?>

						<div class="top-search">
						 	<a id="trigger-overlay">
						 		<i class="fa fa-search"></i>
						 	</a>

						 	<div class="search-overlay">
						 		<div class="search-row">
						 			<a ahref="#" class="overlay-close"><i class="fa fa-times"></i></a>
									
									<form method="get" id="searchform" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>" _lpchecked="1">
										<input type="text" name="s" id="s" value="<?php echo get_search_query(); ?>" placeholder="<?php esc_html_e('Search ...', 'superclick'); ?>" />
									</form>
						 		</div>							 		
						 	</div>
						</div><!-- .top-search -->

					</nav><!-- #site-navigation -->

				<?php endif; ?>
			</div>
		</div>

		<div id="catcher" ></div>
	</header><!-- #masthead -->
<?php endif; ?>

	<div id="content" class="site-content">
		<div class="inner">

		<?php // Display Magazine Homepage Widgets.
		if ( is_page_template('page-magazine.php') ) : ?>

			<div id="magazine-homepage-widgets" class="magazine-featured clearfix">

				<?php dynamic_sidebar( 'feature-homepage' ); ?>

			</div><!-- #magazine-homepage-widgets -->

		<?php
		endif;
		?>
