<?php
/**
 * The sidebar containing the main widget area.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Superclick
 */

if ( is_active_sidebar( 'superclick-sidebar-left' )) : ?>
	<aside id="sidebar-left" class="widget-area sidebar-left col-xs-12 col-sm-4 col-md-2 col-lg-2" role="complementary">
		
		<?php dynamic_sidebar( 'superclick-sidebar-left' ); ?>
		
	</aside><!-- #secondary -->
<?php endif; ?>