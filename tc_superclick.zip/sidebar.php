<?php
/**
 * The sidebar containing the main widget area.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Superclick
 */
$theme_options = superclick_theme_options();

if ( ! is_active_sidebar( 'superclick-sidebar-right' ) ) {
	return;
}

if ( $theme_options['sidebar_layout'] != 'no-sidebar' ) {
?>

	<aside id="secondary" class="widget-area sidebar-right col-xs-12 col-sm-8 col-md-3 col-lg-4" role="complementary">
		
		<?php dynamic_sidebar( 'superclick-sidebar-right' ); ?>
		
	</aside><!-- #secondary -->

<?php
}
?>
