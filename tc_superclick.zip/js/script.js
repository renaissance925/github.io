jQuery.fn.exists = function(callback) {
	var args = [].slice.call(arguments, 1);
	if (this.length) {
		callback.call(this, args);
	}
	return this;
};
(function ($) {
	'use strict';

	var tocial = {
		initReady: function() {
			this.mobileMenu();
			this.scrollTop();
			this.stickyMenu();
			this.socialSharer();
			this.headerSearch();

			if (typeof load_style != 'undefined') {
				if (load_style === 'paging-infinite') {
					this.infiniteScroll();
				} else {
					this.infiniteLoading();
				}
			}
		},

		headerSearch: function() {
			$('#trigger-overlay').on('click', function(e) {
				e.preventDefault();
				$('.search-overlay').toggleClass('show');
				$('.search-row').find('input').focus();
			});
			$('.overlay-close').on('click', function(e){
				$('.search-overlay').removeClass('show');
			});
		},

		socialSharer: function() {
			if( $('.tc-social-sharing').length ) {
				$('.tc-social-sharing a').jqSocialSharer();

				$('.btn-hide').on('click', function(e) {
					e.preventDefault();
					var open = $(this).hasClass('active');
					if(!open) {
						$(this).addClass('active');
						$('.sticky-left').addClass('hide-social');
					} else {
						$(this).removeClass('active');
						$('.sticky-left').removeClass('hide-social');
					}
				});
			}
		},

		stickyMenu: function() {
			var self = this;

			var catcher = $('#catcher'),
				sticky  = $('#sticky'),
				bodyTop = $('body').offset().top;
//if ( sticky.length && $('body').hasClass('default-superclick-layout') ) {
			if ( sticky.length ) {
				$(window).scroll(function() {
					self.stickThatMenu(sticky, catcher, bodyTop);
				});
				$(window).resize(function() {
					self.stickThatMenu(sticky, catcher, bodyTop);
				});
			}
		},

		stickThatMenu: function(sticky,catcher,top) {
			var self = this;
			var stopHeight = catcher.offset().top;

			if( self.isScrolledTo(sticky, top) ) {
				sticky.addClass('sticky-menu');
				catcher.height(sticky.height());
			}

			if ( stopHeight > sticky.offset().top ) {
				$('#sticky').removeClass('sticky-menu');
				catcher.height(0);
			}
		},

		isScrolledTo: function(elem,top) {
			var docViewTop = $(window).scrollTop(); //num of pixels hidden above current screen
			var docViewBottom = docViewTop + $(window).height();

			var elemTop = $(elem).offset().top - top; //num of pixels above the elem
			var elemBottom = elemTop + $(elem).height();

			return ((elemTop <= docViewTop));
		},

		mobileMenu: function() {
			var $top_menu = $('.main-navigation');
			var $secondary_menu = $('.primary-navigation');
			var $first_menu = '';
			var $second_menu = '';

			$('.sub-menu').parent().append('<span class="arrow-menu"><i class="fa arrow-sub-menu fa-chevron-right"></i></span>');

			if ( $top_menu.length == 0 && $secondary_menu.length == 0 ) {
				return;
			} else {
				if ( $top_menu.length ) {
					$first_menu = $top_menu;
					if ( $secondary_menu.length ) {
						$second_menu = $secondary_menu;
						$('.top-nav').addClass('has-second-menu');
					}
				} else {
					$first_menu = $secondary_menu;
				}
			}
			var menu_wrapper = $first_menu
			.clone().attr('class', 'mobile-menu')
			.wrap('<div id="mobile-menu-wrapper" class="mobile-only"></div>').parent()
			.appendTo('body');
			
			// Add items from the other menu
			if ( $second_menu.length ) {
				$second_menu.clone().appendTo('#mobile-menu-wrapper');
			}

			$('.navbar-toggle, .navbar-brand').click(function(e) {
				e.preventDefault();
				e.stopPropagation();
				$('#mobile-menu-wrapper').show();
				$('body').toggleClass('mobile-menu-active');
			});

			$('#page').click(function() {
				if ($('body').hasClass('mobile-menu-active')) {
					$('body').removeClass('mobile-menu-active');
				}
			});

			if($('#wpadminbar').length) {
				$('#mobile-menu-wrapper').addClass('wpadminbar-active');
			}

			$('.arrow-menu').on('click', function(e) {
				e.preventDefault();
				e.stopPropagation();
				var subMenuOpen = $(this).hasClass('sub-menu-open');

				if ( subMenuOpen ) {
					$(this).removeClass('sub-menu-open');
					$(this).find('i').removeClass('fa-chevron-down').addClass('fa-chevron-right');
					$(this).prev('ul.sub-menu').slideUp();
				} else {
					$(this).prev('ul.sub-menu').slideDown();
					$(this).addClass('sub-menu-open');
					$(this).find('i').removeClass('fa-chevron-right').addClass('fa-chevron-down');
				}

			});

		},

		infiniteLoading: function() {
			var page_pumber = 2;
			var refresh_icon = '<i class="fa fa-refresh"></i> ';

			$('#load-more-post').on('click', function(e) {

				if ( page_pumber <= total_pages ) {
					var that = this;
					e.preventDefault();
					$.ajax({
						url: superclickAjax.ajaxurl,
						type:'POST',
						data: 'action=infinite_scroll&page_no='+ page_pumber,
						beforeSend : function() {
							$(that).html(refresh_icon + $(that).data('loading'));
							$(that).addClass('active-loading');
						}
					}).done(function(html) {
						console.log(html);
						$('.site-main').append(html);
						$(that).html(refresh_icon + $(that).data('more'));
						$(that).removeAttr('class');
					});
					page_pumber++;

					if ( page_pumber > total_pages ) {
						$(this).parent().hide();
					}
				}
				e.preventDefault();
			});
		},
		infiniteScroll: function() {
			var page_pumber = 2;
			var is_loading = false;
			$(window).scroll(function(){

				if( $(window).scrollTop() + $(window).height() > $('#main').height() ) {

					if (page_pumber <= total_pages && is_loading === false) {
						$.ajax({
							url: superclickAjax.ajaxurl,
							type: 'POST',
							data: 'action=infinite_scroll&page_no='+ page_pumber,
							beforeSend: function () {
								is_loading = true;
								$('.infinite-scroll').fadeIn();
							},
							success: function (data) {
								$('.site-main').append(data);
								is_loading = false;
								page_pumber++;
								$('.infinite-scroll').fadeOut();
							}
							
						});
					}
				}
			});
		},

		scrollTop: function() {
			var scrollDes = 'html,body';  
			// Opera does a strange thing if we use 'html' and 'body' together so my solution is to do the UA sniffing thing
			if(navigator.userAgent.match(/opera/i)){
				scrollDes = 'html';
			}
			// Show ,Hide
			$(window).scroll(function () {
				if ($(this).scrollTop() > 130) {
					$('.back-to-top').addClass('filling').removeClass('hiding');
					$('.sharing-top-float').fadeIn();
				} else {
					$('.back-to-top').removeClass('filling').addClass('hiding');
					$('.sharing-top-float').fadeOut();
				}
			});
			// Scroll to top when click
			$('.back-to-top').click(function () {
				$(scrollDes).animate({ 
					scrollTop: 0
				},{
					duration :500
				});

			});
		},

	}
	$(document).ready(function () {
		tocial.initReady();
	});

})(jQuery);