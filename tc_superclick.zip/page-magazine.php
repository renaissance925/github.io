<?php
/**
 * Template Name: Magazine Homepage
 *
 * @package Superclick
 */

$theme_options = superclick_theme_options();

get_header(); ?>

	<?php
	if ( $theme_options['sidebar_layout'] != 'no-sidebar' ) {
		get_sidebar( 'left' );
	}
	?>

	<div id="primary" class="content-area col-xs-12 col-sm-8 col-md-7 col-lg-7">

		<?php superclick_ads_under_nav(); ?>

		<main id="main" class="site-main" role="main">

			<?php
			if ( is_page_template('page-magazine.php') ) :
			?>

				<div id="magazine-homepage-widgets" class="magazine-featured-list clearfix">

					<?php dynamic_sidebar( 'magazine-homepage' ); ?>

				</div><!-- #magazine-homepage-widgets -->

			<?php
			else :
				if ( current_user_can( 'edit_theme_options' ) ) : ?>

					<p class="empty-widget-area">
						<?php esc_html_e( 'Please go to Appearance &#8594; Widgets and add at least one widget to the "Magazine Homepage" widget area. You can use the Magazine Posts widgets to set up the theme like the demo website.', 'blackwhite' ); ?>
					</p>

				<?php endif;

			endif; ?>
		
		</main><!-- #main -->
		
		<?php
			superclick_the_posts_navigation();
			superclick_ads_above_footer();
		?>

	</div><!-- #primary -->

<?php
get_sidebar();
get_footer();
