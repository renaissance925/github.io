<?php
/**
 * Pro Version Upgrade Section
 *
 * Registers Upgrade Section for the Pro Version of the theme
 *
 * @package Superclick
 */


/**
 * Adds pro version description
 *
 * @param object $wp_customize / Customizer Object
 */
function superclick_customize_register_upgrade_options( $wp_customize ) {

	// Add Upgrade / More Features Section
	$wp_customize->add_section( 'superclick_section_upgrade', array(
        'title'    => esc_html__( 'More Features', 'superclick' ),
        'priority' => 70,
		'panel' => 'superclick_options_panel' 
		)
	);
	
	// Add custom Upgrade Content control
	$wp_customize->add_setting( 'superclick_theme_options[upgrade]', array(
        'default'           => '',
		'type'           	=> 'option',
        'transport'         => 'refresh',
        'sanitize_callback' => 'esc_attr'
        )
    );
    $wp_customize->add_control( new superclick_Customize_Upgrade_Control(
        $wp_customize, 'superclick_theme_options[upgrade]', array(
            'section' => 'superclick_section_upgrade',
            'settings' => 'superclick_theme_options[upgrade]',
            'priority' => 1
            )
        )
    );

}
add_action( 'customize_register', 'superclick_customize_register_upgrade_options' );