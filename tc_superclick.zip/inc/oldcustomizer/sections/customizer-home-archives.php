<?php
/**
 * Archive Settings
 *
 * Register Home & Archive Settings section, settings and controls for Theme Customizer
 *
 * @package Superclick
 */


/**
 * Adds post settings in the Customizer
 *
 * @param object $wp_customize / Customizer Object
 */
function superclick_customize_register_archive_options( $wp_customize ) {

	// Add Sections for Post Settings
	$wp_customize->add_section( 'superclick_section_home_archive', array(
        'title'    => esc_html__( 'Home & Archive Settings', 'superclick' ),
        'priority' => 20,
		'panel' => 'superclick_options_panel' 
		)
	);
	
	// Add Settings and Controls for Post length on home & archives
	$wp_customize->add_setting( 'superclick_theme_options[post_content]', array(
        'default'           => 'excerpt',
        'type'           	=> 'option',
        'transport'         => 'refresh',
        'sanitize_callback' => 'superclick_sanitize_select'
		)
	);
    $wp_customize->add_control( 'superclick_theme_options[post_content]', array(
        'label'    => esc_html__( 'Post length on home & archives', 'superclick' ),
        'section'  => 'superclick_section_home_archive',
        'settings' => 'superclick_theme_options[post_content]',
        'type'     => 'radio',
		'priority' => 1,
        'choices'  => array(
            'index' => esc_html__( 'Show full posts', 'superclick' ),
            'excerpt' => esc_html__( 'Show post excerpts', 'superclick' )
			)
		)
	);
	

	// Add Setting and Control for Excerpt Length
	$wp_customize->add_setting( 'superclick_theme_options[excerpt_length]', array(
        'default'           => 20,
		'type'           	=> 'option',
		'transport'         => 'refresh',
        'sanitize_callback' => 'absint'
		)
	);
    $wp_customize->add_control( 'superclick_theme_options[excerpt_length]', array(
        'label'    => esc_html__( 'Excerpt Length', 'superclick' ),
        'section'  => 'superclick_section_home_archive',
        'settings' => 'superclick_theme_options[excerpt_length]',
        'type'     => 'text',
		'active_callback' => 'superclick_control_post_content_callback',
		'priority' => 2
		)
	);
	

	// Add Setting and Control for Excerpt More Text
	$wp_customize->add_setting( 'superclick_theme_options[excerpt_more]', array(
        'default'           => '[...]',
		'type'           	=> 'option',
		'transport'         => 'refresh',
        'sanitize_callback' => 'esc_attr'
		)
	);

    $wp_customize->add_control( 'superclick_theme_options[excerpt_more]', array(
        'label'    => esc_html__( 'Excerpt More Text', 'superclick' ),
        'section'  => 'superclick_section_home_archive',
        'settings' => 'superclick_theme_options[excerpt_more]',
        'type'     => 'text',
        'active_callback' => 'superclick_control_post_content_callback',
		'priority' => 3
		)
	);
	
	
	

    // Add Settings and Controls for Pagination
    $wp_customize->add_setting( 'superclick_theme_options[paging]', array(
        'default'           => 'pageing-default',
        'type'              => 'option',
        'transport'         => 'refresh',
        'sanitize_callback' => 'superclick_sanitize_select'
        )
    );
    $wp_customize->add_control( 'superclick_theme_options[paging]', array(
        'label'    => esc_html__( 'Pagination Type', 'superclick' ),
        'section'  => 'superclick_section_home_archive',
        'settings' => 'superclick_theme_options[paging]',
        'type'     => 'radio',
        'priority' => 4,
        'choices'  => array(
            'pageing-default' => esc_html__( ' Default ( Older posts/Newer posts )', 'superclick' ),
            'pageing-numberal' => esc_html__( 'Numberal (1 2 3 ..)', 'superclick' )
            )
        )
    );

    // Add Post Meta Settings
    $wp_customize->add_setting( 'superclick_theme_options[postmeta_headline]', array(
        'default'           => '',
        'type'              => 'option',
        'transport'         => 'refresh',
        'sanitize_callback' => 'esc_attr'
        )
    );
    $wp_customize->add_control( new superclick_Customize_Header_Control(
        $wp_customize, 'superclick_theme_options[postmeta_headline]', array(
            'label' => esc_html__( 'Post Meta', 'superclick' ),
            'section' => 'superclick_section_home_archive',
            'settings' => 'superclick_theme_options[postmeta_headline]',
            'priority' => 4
            )
        )
    );
    
	// Post meta info
	$wp_customize->add_setting( 'superclick_theme_options[meta_date]', array(
        'default'           => true,
		'type'           	=> 'option',
        'transport'         => 'refresh',
        'sanitize_callback' => 'superclick_sanitize_checkbox'
		)
	);
    $wp_customize->add_control( 'superclick_theme_options[meta_date]', array(
        'label'    => esc_html__( 'Display post date', 'superclick' ),
        'section'  => 'superclick_section_home_archive',
        'settings' => 'superclick_theme_options[meta_date]',
        'type'     => 'checkbox',
		'priority' => 5
		)
	);
	
	$wp_customize->add_setting( 'superclick_theme_options[meta_author]', array(
        'default'           => true,
		'type'           	=> 'option',
        'transport'         => 'refresh',
        'sanitize_callback' => 'superclick_sanitize_checkbox'
		)
	);
    $wp_customize->add_control( 'superclick_theme_options[meta_author]', array(
        'label'    => esc_html__( 'Display post author', 'superclick' ),
        'section'  => 'superclick_section_home_archive',
        'settings' => 'superclick_theme_options[meta_author]',
        'type'     => 'checkbox',
		'priority' => 6
		)
	);
	
	$wp_customize->add_setting( 'superclick_theme_options[meta_category]', array(
        'default'           => true,
		'type'           	=> 'option',
        'transport'         => 'refresh',
        'sanitize_callback' => 'superclick_sanitize_checkbox'
		)
	);
    $wp_customize->add_control( 'superclick_theme_options[meta_category]', array(
        'label'    => esc_html__( 'Display post categories', 'superclick' ),
        'section'  => 'superclick_section_home_archive',
        'settings' => 'superclick_theme_options[meta_category]',
        'type'     => 'checkbox',
		'priority' => 7
		)
	);
	
	
}
add_action( 'customize_register', 'superclick_customize_register_archive_options' );