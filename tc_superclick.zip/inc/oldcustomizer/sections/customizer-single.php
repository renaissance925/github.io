<?php
/**
 * Single Settings
 *
 * Register Single Settings section, settings and controls for Theme Customizer
 *
 * @package Superclick
 */


/**
 * Adds post settings in the Customizer
 *
 * @param object $wp_customize / Customizer Object
 */
function superclick_customize_register_single_options( $wp_customize ) {
		// Add Section for Theme Options
		$wp_customize->add_section( 'superclick_section_single', array(
	        'title'    => esc_html__( 'Single Post Settings', 'superclick' ),
	        'priority' => 30,
			'panel' => 'superclick_options_panel' 
			)
		);

		// Add Settings and Controls for Post length on home & archives
		$wp_customize->add_setting( 'superclick_theme_options[related_posts]', array(
	        'default'           => 'cat',
	        'type'           	=> 'option',
	        'transport'         => 'refresh',
	        'sanitize_callback' => 'superclick_sanitize_select'
			)
		);
	    $wp_customize->add_control( 'superclick_theme_options[related_posts]', array(
	        'label'    => esc_html__( 'Related posts', 'superclick' ),
	        'section'  => 'superclick_section_single',
	        'settings' => 'superclick_theme_options[related_posts]',
	        'type'     => 'radio',
			'priority' => 1,
	        'choices'  => array(
	            'cat' => esc_html__( 'Categories', 'superclick' ),
	            'tag' => esc_html__( 'Tags', 'superclick' )
				)
			)
		);
	}
add_action( 'customize_register', 'superclick_customize_register_single_options' );