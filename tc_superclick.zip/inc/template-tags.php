<?php
/**
 * Custom template tags for this theme.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package Superclick
 */

if ( ! function_exists('superclick_header_title') ) :
/**
 |------------------------------------------------------------------------------
 | Logo Section
 |------------------------------------------------------------------------------
 */
	function superclick_header_title() {

		$output = '';
		$description = get_bloginfo( 'description', 'display' );

		if ( function_exists( 'has_custom_logo' ) && has_custom_logo()  ) {
			$output = sprintf('<h1 class="site-title logo" itemprop="headline"> %s </h1>', get_custom_logo() ); ?>
		<?php
		} else {
			if ( is_front_page() || is_home() ) { ?>
				<?php $output = sprintf( '<h1 class="site-title"><a href=" %s " rel="home" title="'. $description .'" > %s </a></h1><h2 class="site-description">'. $description .'</h2>', esc_url( home_url('/') ), get_bloginfo('name') ); ?>
			<?php
			} else {
			?>
				<?php $output = sprintf( '<h2 class="site-title"><a href="%s" rel="home" title="'. $description .'" > %s </a></h2><h3 class="site-description">'. $description .'</h3>', esc_url( home_url('/') ), get_bloginfo('name') ); ?>
			<?php
			}
		}

	echo $output;
	}
endif;


if ( ! function_exists( 'superclick_entry_meta' ) ) :
/**
 * Prints HTML with meta information for the current post-date/time and author.
 */
function superclick_entry_meta() {

	$theme_options = superclick_theme_options();
	$meta_options = array_flip( $theme_options['post_meta_info'] );

	echo('<div class="entry-meta">');

		$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			$time_string = '<time class="entry-date published" datetime="%3$s">%4$s</time>';
		}

		$time_string = sprintf( $time_string,
			esc_attr( get_the_date( 'c' ) ),
			esc_html( get_the_date() ),
			esc_attr( get_the_modified_date( 'c' ) ),
			esc_html( get_the_modified_date() )
		);

		$posted_on = sprintf(
			esc_html_x( '%s', 'post date', 'superclick' ),
			'<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>'
		);

		$byline = sprintf(
			esc_html_x( '%s', 'post author', 'superclick' ),
			'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
		);

		if ( isset( $meta_options[ 'meta-author' ] ) ) {
			echo '<span class="byline"><i class="fa fa-user" aria-hidden="true"></i>' . $byline . '</span>';
		}
		if ( isset( $meta_options[ 'meta-date' ] ) ) {
			echo '<span class="posted-on"><i class="fa fa-calendar" aria-hidden="true"></i>' . $posted_on . '</span>'; // WPCS: XSS OK.
		}

		// Hide category and tag text for pages.
		if ( 'post' === get_post_type() ) {
			/* translators: used between list items, there is a space after the comma */
			$categories_list = get_the_category_list( esc_html__( ', ', 'superclick' ) );
			if ( $categories_list && superclick_categorized_blog() && isset( $meta_options[ 'meta-category' ] ) ) {
				printf( '<span class="cat-links"><i class="fa fa-file" aria-hidden="true"></i>' . esc_html__( ' %1$s', 'superclick' ) . '</span>', $categories_list ); // WPCS: XSS OK.
			}

			/* translators: used between list items, there is a space after the comma */
			$tags_list = get_the_tag_list( '', esc_html__( ', ', 'superclick' ) );
			if ( $tags_list && isset( $meta_options[ 'meta-tag' ] ) ) {
				printf( '<span class="tags-links"><i class="fa fa-tags" aria-hidden="true"></i>' . esc_html__( ' %1$s', 'superclick' ) . '</span>', $tags_list ); // WPCS: XSS OK.
			}
		}

		edit_post_link(
			sprintf(
				/* translators: %s: Name of current post */
				esc_html__( 'Edit %s', 'superclick' ),
				the_title( '<span class="screen-reader-text">"', '"</span>', false )
			),
			'<span class="edit-link">',
			'</span>'
		);

	echo('</div><!-- .entry-meta -->');

}
endif;

/**
 * Returns true if a blog has more than 1 category.
 *
 * @return bool
 */
function superclick_categorized_blog() {
	if ( false === ( $all_the_cool_cats = get_transient( 'superclick_categories' ) ) ) {
		// Create an array of all the categories that are attached to posts.
		$all_the_cool_cats = get_categories( array(
			'fields'     => 'ids',
			'hide_empty' => 1,
			'number'     => 2,
		) );

		// Count the number of categories that are attached to the posts.
		$all_the_cool_cats = count( $all_the_cool_cats );

		set_transient( 'superclick_categories', $all_the_cool_cats );
	}

	if ( $all_the_cool_cats > 1 ) {
		// This blog has more than 1 category so superclick_categorized_blog should return true.
		return true;
	} else {
		// This blog has only 1 category so superclick_categorized_blog should return false.
		return false;
	}
}

/**
 * Flush out the transients used in superclick_categorized_blog.
 */
function superclick_category_transient_flusher() {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	// Like, beat it. Dig?
	delete_transient( 'superclick_categories' );
}
add_action( 'edit_category', 'superclick_category_transient_flusher' );
add_action( 'save_post',     'superclick_category_transient_flusher' );


/**
|------------------------------------------------------------------------------
| Infinite loading and more button
|------------------------------------------------------------------------------
| 
| @return void
|
*/
function superclick_infinite_loading($load_style = 'loadding') {
	global $wp_query;
	$total_pages = $wp_query->max_num_pages;

	if ($total_pages > 1) :

		if ($load_style != 'paging-infinite'):
		?>
			<div id="load-more-wrap">
				<a id="load-more-post" href="#" data-loading="<?php _e('Loading...', 'superclick') ?>" data-more="Load more..."><i class="fa fa-refresh"></i> <?php _e('Load more...', 'superclick') ?></a>
			</div>

		<?php

		endif;
		?>

		<script type="text/javascript">
			var total_pages = <?php echo $total_pages ?>;
			var load_style = '<?php echo $load_style; ?>';
		</script>

		<?php

	endif;
}

if (! function_exists('superclick_infinitepaginate')):

	/**
	|------------------------------------------------------------------------------
	| Ajax Infinite Scroll
	|------------------------------------------------------------------------------
	| 
	| @return void
	|
	*/

	function superclick_infinitepaginate(){

		$paged           = $_POST['page_no'];
		$posts_per_page  = get_option('posts_per_page');
		$theme_options   = superclick_theme_options();

		$post_format = $theme_options['post_layout_style'] == 'post-grid' ? 'grid' : get_post_format();

		# Load the posts
		query_posts(array('paged' => $paged ));

		while ( have_posts() ) {
			the_post();
			get_template_part( 'template-parts/content', $post_format );
		}
		exit;
	}

	add_action('wp_ajax_infinite_scroll', 'superclick_infinitepaginate');        // for logged in user
	add_action('wp_ajax_nopriv_infinite_scroll', 'superclick_infinitepaginate');

endif;


if ( ! function_exists( 'superclick_the_posts_navigation' ) ) :
/**
 |------------------------------------------------------------------------------
 | Display navigation to next/previous set of posts when applicable.
 |------------------------------------------------------------------------------
 |
 | @todo Remove this function when WordPress 4.3 is released.
 |
 */
function superclick_the_posts_navigation() {
	
	// Don't print empty markup if there's only one page.
	if ( $GLOBALS['wp_query']->max_num_pages < 2 ) {
		return;
	}

	$theme_options = superclick_theme_options();
	$nav_style = $theme_options['paging'];

	if ( $nav_style == 'paging-infinite' ) :

		superclick_infinite_loading('paging-infinite');

	elseif ( $nav_style == 'paging-numberal' ) :
		// Previous/next page navigation.
		
		echo '<div class="content-pagination">';
			the_posts_pagination( array(
				'prev_text'          => __( '<i class="fa fa-chevron-left"></i>', 'superclick' ),
				'next_text'          => __( '<i class="fa fa-chevron-right"></i>', 'superclick' ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'superclick' ) . ' </span>',
			) );
		echo '</div>';

	elseif ( $nav_style == 'paging-loading' ) :

		superclick_infinite_loading();

	else :

	?>
	<nav class="paging-navigation clearfix" role="navigation">
		<span class="screen-reader-text"><?php _e( 'Posts navigation', 'superclick' ); ?></span>
		<div class="nav-links">

			<?php if ( get_next_posts_link() ) : ?>
			<div class="nav-previous"><?php next_posts_link( __( ' Older posts', 'superclick' ) ); ?></div>
			<?php endif; ?>

			<?php if ( get_previous_posts_link() ) : ?>
			<div class="nav-next"><?php previous_posts_link( __( 'Newer posts ', 'superclick' ) ); ?></div>
			<?php endif; ?>

		</div><!-- .nav-links -->
	</nav><!-- .navigation -->
	<?php
	endif;
}
endif;


if ( ! function_exists( 'superclick_post_nav' ) ) :
/**
 * Display navigation to next/previous post when applicable.
 */
function superclick_post_nav() {
	// Don't print empty markup if there's nowhere to navigate.
	$previous = ( is_attachment() ) ? get_post( get_post()->post_parent ) : get_adjacent_post( false, '', true );
	$next     = get_adjacent_post( false, '', false );

	if ( ! $next && ! $previous ) {
		return;
	}
	?>
	<nav class="post-navigation clearfix" role="navigation">
		<h1 class="screen-reader-text"><?php _e( 'Post navigation', 'superclick' ); ?></h1>
		<div class="nav-links">
			<?php
				previous_post_link( '<div class="nav-previous">%link</div>', _x( '%title', 'Previous post link', 'superclick' ) );
				next_post_link(     '<div class="nav-next">%link</div>',     _x( '%title', 'Next post link',     'superclick' ) );
			?>
		</div><!-- .nav-links -->
	</nav><!-- .navigation -->
	<?php
}
endif;

if (!function_exists('superclick_social_icons')) :
/**
 * Social icons 
 */
function superclick_social_icons($position) {	
	$theme_options = superclick_theme_options();

	if ($theme_options['social_sharing_button'] == 1 ) :

		$social_items = array_flip($theme_options['enable_social_sharing_button']);

		global $post;
		?>

		<div class="tc-social-sharing clearfix <?php echo "$position"; ?>">
			<ul class="tc-social-icons clearfix">		
			<?php if ( isset( $social_items['facebook'] ) ) : ?>	
				<li class="facebook">
					<a href="#" class="facebook" data-social='{"type":"facebook", "url":"<?php echo urlencode(the_permalink()); ?>", "text": "<?php the_title(); ?>"}' title="<?php the_title(); ?>" rel="nofollow"><i class="fa fa-facebook"></i><span class="text">facebook</span></a>
				</li>
			<?php endif; ?>

			<?php if ( isset( $social_items['twitter'] ) ) : ?>	
				<li class="twitter">					
					<a href="#" class="twitter" data-social='{"type":"twitter", "url":"<?php echo urlencode(the_permalink()); ?>&via=<?php echo $theme_options['twitter_username']; ?>", "text": "<?php the_title(); ?>"}' title="<?php the_title(); ?>" rel="nofollow"><i class="fa fa-twitter"></i><span class="text">tweet</span></a>
				</li> 
			<?php endif; ?>
			

			<?php if ( isset( $social_items['googleplus'] ) ) : ?>	
				<li class="googleplus">
					<a href="#" class="plusone" data-social='{"type":"plusone", "url":"<?php echo urlencode(the_permalink()); ?>", "text": "<?php the_title(); ?>"}' title="<?php the_title(); ?>" rel="nofollow"><i class="fa fa-google-plus"></i><span class="text">google+</span></a>
				</li>
			<?php endif; ?>

			<?php if ( isset( $social_items['pinterest'] ) ) : ?>	
				<li class="pinterest">
					<a href="#" class="pinterest" data-social='{"type":"pinterest", "url":"<?php echo urlencode(the_permalink()); ?>", "text": "<?php the_title(); ?>", "image": "<?php if ( has_post_thumbnail() ) { echo wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) ); } ?>"}' title="<?php the_title(); ?>" rel="nofollow"><i class="fa fa-pinterest"></i><span class="text">pinterest</span>
					</a>
				</li>
			<?php endif; ?>

			<?php if ( isset( $social_items['linkedin'] ) ) : ?>	
				<li class="linkedin">
					<a href="#" class="linkedin" data-social='{"type":"linkedin", "url":"<?php echo urlencode(the_permalink()); ?>", "text": "<?php the_title(); ?>", "summary": "<?php echo get_the_excerpt(); ?>"}' title="<?php the_title(); ?>" rel="nofollow"><i class="fa fa-linkedin"></i><span class="text">linkedin</span></a>
				</li>
			<?php endif; ?>
		</ul>
	</div>


	<?php		
	endif;
}

endif;