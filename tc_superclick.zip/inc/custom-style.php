<?php 

if ( ! function_exists( 'superclick_custom_style' ) ) :

/**
|------------------------------------------------------------------------------
| Generate custom style from theme option
|------------------------------------------------------------------------------
 */

function superclick_custom_style() {

		$theme_options = superclick_theme_options();	
		$primary_color = $theme_options['primary_color']; //#f3f3f3

	?>

		<style type="text/css">

			<?php if( $theme_options['custom_default_color'] == 1 ) : ?>
				.back-to-top,
				.btn-read-more,
				.btn-default a,
				.nav-previous a,
				.nav-next a,
				.info-category span,
				.comments-area .comment-respond .comment-reply-title,
				.comments-area .comments-title,
				.comments-area .comment-meta .comment-metadata,
				.comments-area .reply .comment-reply-link:hover,
				.related-posts h3,
				.title-bio,
				.navbar-header,
				.comments-area p.form-submit input,
				.header-social-sharing ul li a:hover,
				.search-form .search-submit,
				button, input[type="button"],
				input[type="reset"],
				input[type="submit"],
				#wp-calendar caption {
					background-color: <?php echo $primary_color ?>;
				}

				.pagination .nav-links a,
				#load-more-wrap {
					border-color: <?php echo $primary_color ?>;
				}

				a,
				.bio-name a,
				.btn-hide.active,
				.btn-hide:hover,
				.site-info .left-path a:hover,
				.ewidget a:hover,
				.seoyoast-breadcrumb a,
				.widget_recent_comments ul li a,
				.smenu ul li a:hover,
				.bio-name a,
				.calendar_wrap caption,
				.entry-title a,
				.entry-meta span a:hover,
				.entry-meta span a:hover *,
				.comment-respond .logged-in-as a:hover,
				.tagcloud a,
				.widget ul li a,
				.related-posts ul li a,
				.bio-name,
				.bio-desc,
				ul li:before,
				.la-ball-spin-clockwise.la-dark,		
				.posts-navigation .nav-next a,
				.pagination .nav-links a,
				.site-info .left-path a:hover,
				.site-info .right-path a:hover,
				#crumbs,
				#crumbs a,
				#load-more-wrap a,
				.entry-title a, .h1, .h2, .h3, .h4, .h5, .h6,
				.single-title, h1, h2, h3, h4, h5, h6,
				table th a,
				table td a {
					color: <?php echo $primary_color ?>;
				}

			<?php endif; ?>

			<?php
				echo html_entity_decode( $theme_options['custom_css'], ENT_QUOTES );
			?>
		</style>

	<?php
	}

add_action('wp_head','superclick_custom_style');
endif;