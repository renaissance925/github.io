<?php
/**
|------------------------------------------------------------------------------
| Display Top Home & Archive page Ads: 300x250
|------------------------------------------------------------------------------
*/
function superclick_ads_under_nav () {

	$theme_options	= superclick_theme_options();
	$show_on		= array_flip($theme_options['position_ads_under_navigation']);
	$ads_code		= html_entity_decode($theme_options['ads_under_navigation'], ENT_QUOTES);

	if ( !empty( $ads_code ) && $theme_options['showhide_ads_under_navigation'] == 1 && !empty( $show_on )  ) { 

		if ( (is_home() || is_front_page()) && isset( $show_on['home']) ) :  
		?>

			<div class="ads-fullwidth">
				<div class="ad-content-top clearfix">
				
					<?php echo $ads_code ?>

				</div>
			</div>

		<?php
			elseif ( is_single() && isset( $show_on[ 'single_post'] ) ) :
		?>
			
			<div class="ads-fullwidth">
				<div class="inner clearfix">
					
					<?php echo $ads_code ?>

				</div>
			</div>

		<?php
			elseif ( is_archive() && isset( $show_on['archive'] ) ) :
		?>
			
			<div class="ads-fullwidth">
				<div class="inner clearfix">
					
					<?php echo $ads_code ?>

				</div>
			</div>

		<?php
			elseif ( is_page() && isset( $show_on['single_page'] ) ) :
		?>

			<div class="ads-fullwidth clearfix">
				
				<?php echo $ads_code ?>

			</div>

		<?php
		endif;
	}
}

function superclick_ads_above_footer () {

	$theme_options	= superclick_theme_options();
	$show_on		= array_flip($theme_options['position_ads_under_navigation']);
	$ads_code		= html_entity_decode($theme_options['ads_above_footer'], ENT_QUOTES);

	if ( !empty( $ads_code ) && $theme_options['showhide_ads_above_footer'] == 1 && !empty( $show_on )  ) { 

		if ( (is_home() || is_front_page()) && isset( $show_on['home']) ) :  
		?>

			<div class="ads-fullwidth">
				<div class="ads-above-footer clearfix">
				
					<?php echo $ads_code ?>

				</div>
			</div>

		<?php
			elseif ( is_single() && isset( $show_on[ 'single_post'] ) ) :
		?>
			
			<div class="ads-fullwidth">
				<div class="inner clearfix">
					
					<?php echo $ads_code ?>

				</div>
			</div>

		<?php
			elseif ( is_archive() && isset( $show_on['archive'] ) ) :
		?>
			
			<div class="ads-fullwidth">
				<div class="inner clearfix">
					
					<?php echo $ads_code ?>

				</div>
			</div>

		<?php
			elseif ( is_page() && isset( $show_on['single_page'] ) ) :
		?>

			<div class="ads-fullwidth clearfix">
				
				<?php echo $ads_code ?>

			</div>

		<?php
		endif;
	}
}

if (!function_exists('superclick_ads_content')) :

	/**
	|------------------------------------------------------------------------------
	| Ads Managment
	|------------------------------------------------------------------------------
	| 
	| Three ads postion on single post
	| 
	| 1. After post title (Postions: left, center or right)
	| 2. Middle post content (Position: left, center or right)
	| 3. Below post content (Position: left, center or right)
	| 
	| @return void
	|
	*/

	function superclick_ads_content ($content) {
		
		global $post;
		
		if ( is_single() || is_page() ) {

			$theme_options 	= superclick_theme_options();
			$ads_appearance = array_flip($theme_options['ads_appearance']);
			$show_ad_age	= $theme_options['show_ad_age'];

			if ( is_user_logged_in () && isset($ads_appearance['hide-ad-logg-in'] ) ) {
				return $content;
			}

			if ( !isset($ads_appearance['ad-post']) && is_single() ) {

				return $content;
			
			}

			if ( !isset($ads_appearance['ad-page']) && is_page() ) {
				return $content;
			}

			$today 			= strtotime(date('Y-m-d'));
			$published 		= strtotime(get_the_date('Y-m-d', $post->ID));
			$diff 			= abs($today - $published); 
			$age   			= floor($diff / (60*60*24)); 
			
			if (  $age >= $show_ad_age ) {

				$beginning_ad_code 	= superclick_get_ad_code( $theme_options['ads_beginning_of_post'], $theme_options );
				$middle_ad_code 	= superclick_get_ad_code( $theme_options['ads_middle_of_post'], $theme_options );
				$end_ad_code 		= superclick_get_ad_code( $theme_options['ads_end_of_post'], $theme_options );
				$p_ad_code1 		= superclick_get_ad_code( $theme_options['ads_after_paragraph1'], $theme_options );
				$p_ad_code2 		= superclick_get_ad_code( $theme_options['ads_after_paragraph2'], $theme_options );
				$p_ad_code3 		= superclick_get_ad_code( $theme_options['ads_after_paragraph3'], $theme_options );

				if ( $theme_options[ 'ads_beginning_of_post_enable' ] && $beginning_ad_code ) {

					$content = '<div class="ads-banner-block top-single-ads '. $beginning_ad_code['alignment'] .'">' . $beginning_ad_code['code'] . '</div>' . $content;
				} 

				if ($theme_options[ 'ads_middle_of_post_enable' ] && $middle_ad_code ) {
					$insert_code = '<div class="ads-banner-block middle-single-ads '. $middle_ad_code['alignment'] .'">' . $middle_ad_code['code'] . '</div>';
					$content =  superclick_insert_after_paragraph($insert_code, $content, 0, true);
				}
				
				if ( $theme_options[ 'ads_middle_of_post_enable' ] && $end_ad_code ) {
					$content = $content . '<div class="ads-banner-block below-single-ads '. $end_ad_code['alignment'] .'">' . $end_ad_code['code'] . '</div>';
				}

				// Paragaph 1
				if ($theme_options[ 'ads_after_paragraph_enable1' ] && $p_ad_code1) {

					$insert_code = '<div class="ads-banner-block paragrap-single-ads '. $p_ad_code1['alignment'] .'">' . $p_ad_code1['code'] . '</div>';
					$content =  superclick_insert_after_paragraph($insert_code, $content, $theme_options[ 'ads_after_paragraph_num1' ] );
				}

				// Paragaph 2
				if ($theme_options[ 'ads_after_paragraph_enable2' ] && $p_ad_code2) {

					$insert_code = '<div class="ads-banner-block paragrap-single-ads '. $p_ad_code2['alignment'] .'">' . $p_ad_code2['code'] . '</div>';
					$content =  superclick_insert_after_paragraph($insert_code, $content, $theme_options[ 'ads_after_paragraph_num2' ] );
				}

				// Paragaph 3
				if ($theme_options[ 'ads_after_paragraph_enable3' ] && $p_ad_code3) {

					$insert_code = '<div class="ads-banner-block paragrap-single-ads '. $p_ad_code3['alignment'] .'">' . $p_ad_code3['code'] . '</div>';
					$content =  superclick_insert_after_paragraph($insert_code, $content, $theme_options[ 'ads_after_paragraph_num3' ] );
				}
				
			}

		return $content;

		} else {

			return $content;

		}

	}

	add_filter('the_content', 'superclick_ads_content');

endif;

function superclick_get_ad_code ($ad_code, $theme_options) {
	
	$code 		= false;
	$ad_code 	= trim($ad_code);
	
	if ($ad_code == '') { return false; }

	if ($ad_code != 'random' ) {

		if ( isset($theme_options[ $ad_code ]) && $theme_options[ $ad_code ] != '' ) {

			$code ['code'] = html_entity_decode ($theme_options[ $ad_code ]);
			$code ['alignment'] = isset($theme_options[ 'alignment_'. $ad_code ]) ? $theme_options[ 'alignment_'. $ad_code ] : 'ad-center';
		}

	} else {
		$code = superclick_get_ad_random_code($theme_options);
	}

	return $code;
}

function superclick_get_ad_random_code ($theme_options) {

	$codes 	= array();
	$ads 	= false;

	for ( $i = 1; $i <= 10; $i++ ) {
		if ( isset( $theme_options[ 'ads_code' . $i ] ) && !empty( $theme_options[ 'ads_code' . $i ] ) ) {
			$codes[] = 'ads_code' . $i;
		}
	}

	if ( !empty( $codes ) ) {
		$key 				= array_rand ($codes);
		$ads['code'] 		= html_entity_decode ($theme_options[ $codes[$key] ]);
		$ads['alignment'] 	= isset($theme_options[ 'alignment_'. $codes[$key] ]) ? $theme_options[ 'alignment_'. $codes[$key] ] : 'ad-center';
	}

	return $ads;
}

// Parent Function that makes the magic happen
 
function superclick_insert_after_paragraph( $insertion, $content, $paragraph_id = 1, $middle = false ) {

	$closing_p = '</p>';
	$paragraphs = explode( $closing_p, $content );

	if ( $middle == true ) {
		$paragraph_id = round(count($paragraphs)/2);
	}

	if ( $paragraph_id < 1 ) {

		$content = $insertion . $content;

	} else if ( $paragraph_id >= count($paragraphs)  ) {

		$content = $content . $insertion;

	} else {
		foreach ($paragraphs as $index => $paragraph) {

			if ( trim( $paragraph ) ) {
				$paragraphs[$index] .= $closing_p;
			}

			if ( $paragraph_id == $index + 1 ) {

				$paragraphs[$index] .= $insertion;
			}
		}

		$content = implode( '', $paragraphs );

	}

	
	return $content;
}