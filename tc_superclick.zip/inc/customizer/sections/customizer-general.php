<?php
/**
 * Add the general section
 */
Themecountry_Kirki::add_section( 'superclick_general_section', array(
	'title'      		=> esc_attr__( 'General Settings', 'superclick' ),
	'panel'				=> 'superclick_options_panel',
	'priority'   		=> 1,
	'capability' 		=> 'edit_theme_options',
) );

// Theme Layout
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'custom_super_click_layout',
	'label'    			=> __( 'Theme Layout', 'superclick' ),
	'section'  			=> 'superclick_general_section',
	'type'     			=> 'radio-image',
	'default'     		=> 'custom-layout',
	'priority' 			=> 1,
	'choices'  			=> array(
		'default-layout' 		=> $asset_customizer_path .'/img/style-two.png',
        'custom-layout'			=> $asset_customizer_path .'/img/style-one.png',
	)
) );

// Sidebare Layout
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'sidebar_layout',
	'label'    			=> __( 'Sidebar Layout', 'superclick' ),
	'section'  			=> 'superclick_general_section',
	'type'     			=> 'radio-image',
	'default'     		=> 'right-sidebar',
	'priority' 			=> 1,
	'choices'  			=> array(
			'no-sidebar' 		=> $asset_customizer_path .'/img/col-1cl.png',
            'right-sidebar' 	=> $asset_customizer_path .'/img/col-2cl.png',
	)
) );

// Header Sticky
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'sticky_header',
	'label'    			=> __( 'Sticky Header', 'superclick' ),
	'section'  			=> 'superclick_general_section',
	'type'     			=> 'switch',
	'default'     		=> true,
	'priority' 			=> 1,
) );

// Post length on home & archives
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'post_content',
	'label'    			=> __( 'Post Length on (Home & Archives)', 'superclick' ),
	'section'  			=> 'superclick_general_section',
	'type'     			=> 'radio',
	'default'     		=> 'excerpt',
	'priority' 			=> 1,
	'choices'  			=> array(
            'index' 			=> __( 'Show full posts', 'superclick' ),
            'excerpt' 			=> __( 'Show post excerpts', 'superclick' )
	)
));

// Excerpt Length
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'excerpt_length',
	'label'    			=> __( 'Excerpt Length', 'superclick' ),
	'section'  			=> 'superclick_general_section',
	'type'     			=> 'number',
	'default'			=> 40,
	'priority' 			=> 1,
	'active_callback'	=> array(
			array(
				'setting'  => 'post_content',
				'operator' => '==',
				'value'    => 'excerpt',
			)
		)
) );

// Ecerpt more text
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'excerpt_more',
	'label'    			=> __( 'Excerpt More Ending Text', 'superclick' ),
	'section'  			=> 'superclick_general_section',
	'type'     			=> 'text',
	'default'			=> ' [...]',
	'priority' 			=> 1,
	'active_callback'	=> array(
			array(
				'setting'  => 'post_content',
				'operator' => '==',
				'value'    => 'excerpt',
			)
		)
) );

// Read More
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'read_more_button',
	'label'    			=> __( 'Read More', 'superclick' ),
	'section'  			=> 'superclick_general_section',
	'type'     			=> 'switch',
	'default'     		=> '1',
	'priority' 			=> 1,
) );

// Pagination Styles
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings'			=> 'paging',
	'label'				=> __( 'Pagination Styles', 'superclick' ),
	'section'			=> 'superclick_general_section',
	'type'				=> 'radio',
	'default'			=> 'paging-default',
	'priority'			=> 1,
	'choices'			=> array(
		'paging-default'	=> 'Default ( Older posts/Newer posts )',
		'paging-numberal'	=> 'Numberal (1 2 3 ...)',
		'paging-loading'	=> 'Load More...',
		'paging-infinite'	=> 'Auto Infinite Scroll',
	)
) );

// Post meta info
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'multicheck',
	'settings'    		=> 'post_meta_info',
	'label'       		=> esc_attr__( 'Post Meta Info', 'superclick' ),
	'section'     		=> 'superclick_general_section',
	'default'     		=> array('meta-author', 'meta-date', 'meta-tag', 'meta-category'),
	'priority'    		=> 1,
	'choices'     		=> array(
		'meta-author' 		=> esc_attr__( 'Author', 'superclick' ),
		'meta-date' 		=> esc_attr__( 'Date', 'superclick' ),
		'meta-tag' 			=> esc_attr__( 'Tags', 'superclick' ),
		'meta-category' 	=> esc_attr__( 'Categories', 'superclick' ),
		'meta-comment' 		=> esc_attr__( 'Comment count', 'superclick' ),
	),
) );

// Back to top
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'back_to_top',
	'label'    			=> __( 'Back to Top', 'superclick' ),
	'section'  			=> 'superclick_general_section',
	'type'     			=> 'switch',
	'default'     		=> '1',
	'priority' 			=> 1,
) );

// Header code
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'header_code',
	'label'    			=> __( 'Header Code (wp_head)', 'superclick' ),
	'section'  			=> 'superclick_general_section',
	'type'     			=> 'cutom-code',
	'sanitize_callback'	=> 'superclick_sanitize_textarea_code',
	'priority' 			=> 1,
) );

// Footer code
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'footer_code',
	'label'    			=> __( 'Footer Code (wp_footer)', 'superclick' ),
	'section'  			=> 'superclick_general_section',
	'type'     			=> 'cutom-code',
	'sanitize_callback'	=> 'superclick_sanitize_textarea_code',
	'priority' 			=> 1,
) );