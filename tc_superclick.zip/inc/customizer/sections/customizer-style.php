<?php
/**
 * Add the style section
 */
Themecountry_Kirki::add_section( 'superclick_style_section', array(
	'title'			=> esc_attr__( 'Style Settings', 'superclick' ),
	'panel'			=> 'superclick_options_panel',
	'priority'		=> 2,
	'capability'	=> 'edit_theme_options',
) );

Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'custom_default_color',
	'label'    			=> __( 'Enable Custom Color', 'superclick' ),
	'section'  			=> 'superclick_style_section',
	'type'     			=> 'switch',
	'default'     		=> '0',
	'priority' 			=> 1,
) );

Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'			=> 'color',
	'settings'		=> 'primary_color',
	'label'			=> __( 'Primary Color', 'superclick' ),
	'section'		=> 'superclick_style_section',
	'default'		=> '#0053f9',
	'priority'		=> 1,
	'alpha'			=> true,
	'active_callback'	=> array(
			array(
				'setting'  => 'custom_default_color',
				'operator' => '==',
				'value'    => '1',
			)
		)
) );

// Custom CSS
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings'		=> 'custom_css',
	'label'			=> __( 'Custom CSS', 'superclick' ),
	'section'		=> 'superclick_style_section',
	'type'			=> 'cutom-code',
	'sanitize_callback'	=> 'superclick_sanitize_textarea_code',
	'priority'		=> 1
) );