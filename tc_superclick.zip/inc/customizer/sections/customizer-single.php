<?php
/**
 * Add the single section
 */
Themecountry_Kirki::add_section( 'superclick_single_section', array(
	'title'      	=> esc_attr__( 'Single Post Settings', 'superclick' ),
	'panel'			=> 'superclick_options_panel',
	'priority'   	=> 3,
) );


// Author Breadscrumb
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'breadscrumb',
	'label'    			=> __( 'Breadscrumb', 'superclick' ),
	'section'  			=> 'superclick_single_section',
	'type'     			=> 'switch',
	'default'     		=> false,
	'priority' 			=> 1,
) );
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'breadscrumb_yoast_seo',
	'label'    			=> __( 'Use Yoast SEO breadscrumb', 'superclick' ),
	'section'  			=> 'superclick_single_section',
	'type'     			=> 'checkbox',
	'default'     		=> false,
	'priority' 			=> 1,
	'active_callback'	=> array(
			array(
				'setting'  => 'breadscrumb',
				'operator' => '==',
				'value'    => 1,
			)
		)
) );

// Post Navigation
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'post_nav',
	'label'    			=> __( 'Post Navigation', 'superclick' ),
	'section'  			=> 'superclick_single_section',
	'type'     			=> 'switch',
	'default'     		=> true,
	'priority' 			=> 1,
) );

// Author Bio
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'author_bio',
	'label'    			=> __( 'Author Bio', 'superclick' ),
	'section'  			=> 'superclick_single_section',
	'type'     			=> 'switch',
	'default'     		=> true,
	'priority' 			=> 1,
) );

// Related Posts
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'related_posts',
	'label'    			=> __( 'Enable Related Posts', 'superclick' ),
	'section'  			=> 'superclick_single_section',
	'type'     			=> 'switch',
	'default'     		=> true,
	'priority' 			=> 1,
) );

// Number Related Posts
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'number_related_post',
	'label'    			=> __( 'Number Related Posts', 'superclick' ),
	'section'  			=> 'superclick_single_section',
	'type'     			=> 'number',
	'default'     		=> 6,
	'priority' 			=> 1,
	'active_callback'	=> array(
			array(
				'setting'  => 'related_posts',
				'operator' => '==',
				'value'    => 1,
			)
		)
) );
// Related Posts Taxonomy
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'related_post_taxonomy',
	'label'    			=> __( 'Related Post Taxonomy', 'superclick' ),
	'section'  			=> 'superclick_single_section',
	'type'     			=> 'radio',
	'default'     		=> 'cat',
	'priority' 			=> 1,
	'choices'  			=> array(
            'cat' => esc_html__( 'Categories', 'superclick' ),
            'tag' => esc_html__( 'Tags', 'superclick' )
	),
	'active_callback'	=> array(
			array(
				'setting'  => 'related_posts',
				'operator' => '==',
				'value'    => 1,
			)
		)
) );

// Display Related Posts
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'related_post_display_style',
	'label'    			=> __( 'Related Posts Style', 'superclick' ),
	'section'  			=> 'superclick_single_section',
	'type'     			=> 'radio',
	'default'     		=> 'grid',
	'priority' 			=> 1,
	'choices'  			=> array(
            'grid' => esc_html__( 'Thumbnail and Title', 'superclick' ),
            'list' => esc_html__( 'Only tittle, in list style', 'superclick' )
	),
	'active_callback'	=> array(
			array(
				'setting'  => 'related_posts',
				'operator' => '==',
				'value'    => 1,
			)
		)
) );