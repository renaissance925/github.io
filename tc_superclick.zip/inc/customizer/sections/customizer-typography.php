<?php
/**
 * Add the typography section
 */
Themecountry_Kirki::add_section( 'superclick_typography_section', array(
	'title'      	=> esc_attr__( 'Typography', 'superclick' ),
	'panel'			=> 'superclick_options_panel',
	'priority'   	=> 6,
) );

/**
 * Add the body-typography control
 */
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        => 'typography',
	'settings'    => 'body_typography',
	'label'       => esc_attr__( 'Body Typography', 'superclick' ),
	'description' => esc_attr__( 'Select the main typography options for your site.', 'superclick' ),
	'help'        => esc_attr__( 'The typography options you set here apply to all content on your site.', 'superclick' ),
	'section'     => 'superclick_typography_section',
	'priority'    => 10,
	'default'     => array(
		'font-family'    => 'Open Sans',
		'variant'        => '400',
		'font-size'      => '13px',
		'line-height'    => '1.5',
		'color'          => '#000000',
	),
	'output' => array(
		array(
			'element' => 'body',
		),
	),
) );

/**
 * Add the body-typography control
 */
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        => 'typography',
	'settings'    => 'headers_typography',
	'label'       => esc_attr__( 'Title & Headers Typography', 'superclick' ),
	'description' => esc_attr__( 'Select the typography options for your headers.', 'superclick' ),
	'help'        => esc_attr__( 'The typography options you set here will override the Body Typography options for all headers on your site (post titles, widget titles etc).', 'superclick' ),
	'section'     => 'superclick_typography_section',
	'priority'    => 10,
	'default'     => array(
		'font-family'    => 'Open Sans',
		'variant'        => '400',
		'line-height'    => '1.5',
		'color'          => '#0053f9',
	),
	'output' => array(
		array(
			'element' => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'),
		),
	),
) );