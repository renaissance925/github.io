<?php
/**
 * Add the social buttons section
 */
Themecountry_Kirki::add_section( 'superclick_social_buttons_section', array(
	'title'      	=> esc_attr__( 'Social Button Settings', 'superclick' ),
	'panel'			=> 'superclick_options_panel',
	'priority'   	=> 5,
) );

// Social Sharing Button
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'social_sharing_button',
	'label'    			=> __( 'Social Sharing Buttons', 'superclick' ),
	'section'  			=> 'superclick_social_buttons_section',
	'type'     			=> 'switch',
	'default'     		=> true,
	'priority' 			=> 1,
	
) );

// Twitter Username
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'twitter_username',
	'label'    			=> __( 'Twitter Username', 'superclick' ),
	'section'  			=> 'superclick_social_buttons_section',
	'type'     			=> 'text',
	'priority' 			=> 2,
	'active_callback'	=> array(
			array(
				'setting'  => 'social_sharing_button',
				'operator' => '==',
				'value'    => 1,
			)
		)
	
) );


// Social Sharing Button Position
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        => 'multicheck',
	'settings'    => 'sharing_button_position',
	'label'       => esc_attr__( 'Social Sharing Button Positions', 'superclick' ),
	'section'     => 'superclick_social_buttons_section',
	'default'     => array('sticky-left'),
	'priority'    => 3,
	'choices'     => array(
		'before-content' 		=> esc_attr__( 'Before content', 'superclick' ),
		'after-content' 		=> esc_attr__( 'After content', 'superclick' ),
		'sticky-left' 			=> esc_attr__( 'Sticky left', 'superclick' ),
	),
	'active_callback'	=> array(
			array(
				'setting'  => 'social_sharing_button',
				'operator' => '==',
				'value'    => 1,
			)
		)
) );

// Check to enable social buttons
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        => 'multicheck',
	'settings'    => 'enable_social_sharing_button',
	'label'       => esc_attr__( 'Check to Enable Social Buttons', 'superclick' ),
	'section'     => 'superclick_social_buttons_section',
	'default'     => array('twitter', 'facebook', 'googleplus'),
	'priority'    => 4,
	'choices'     => array(
		'twitter' 			=> esc_attr__( 'Twitter', 'superclick' ),
		'facebook' 			=> esc_attr__( 'Facebook', 'superclick' ),
		'googleplus' 		=> esc_attr__( 'Google Plus', 'superclick' ),
		'linkedin' 			=> esc_attr__( 'Linkedin', 'superclick' ),
		'pinterest' 		=> esc_attr__( 'Pinterest', 'superclick' ),
	),
	'active_callback'	=> array(
			array(
				'setting'  => 'social_sharing_button',
				'operator' => '==',
				'value'    => 1,
			)
		)
) );