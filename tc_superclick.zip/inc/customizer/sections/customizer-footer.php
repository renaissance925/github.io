<?php
/**
 * Add the footer section
 */
Themecountry_Kirki::add_section( 'superclick_footer_section', array(
	'title'			=> esc_attr__( 'Footer Settings', 'superclick' ),
	'panel'			=> 'superclick_options_panel',
	'priority'		=> 4,
) );

Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings'			=> 'footer_widget_col',
	'label'				=> __( 'Footer Widget Columns', 'superclick' ),
	'section'			=> 'superclick_footer_section',
	'type'				=> 'radio-image',
	'default'			=> 'three-col',
	'priority'			=> 1,
	'choices'			=> array(
			'none-col'	=> $asset_customizer_path .'/img/layout-off.png',
			'one-col'		=> $asset_customizer_path .'/img/footer-widgets-1.png',
			'two-col'		=> $asset_customizer_path .'/img/footer-widgets-2.png',
			'three-col'		=> $asset_customizer_path .'/img/footer-widgets-3.png',
			'four-col'		=> $asset_customizer_path .'/img/footer-widgets-4.png',
	)
) );

// Footer Copyright Text
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings'			=> 'footer_copyright_text',
	'label'				=> __( 'Footer Copyright Text', 'superclick' ),
	'section'			=> 'superclick_footer_section',
	'type'				=> 'textarea',
	'default'			=> '&copy;2017 Powered by <a href="https://wordpress.org/">WordPress</a> Theme by <a href="https://themecountry.com/themes/superclick/" rel="designer">SuperClick</a>',
	'priority'			=> 3,
) );