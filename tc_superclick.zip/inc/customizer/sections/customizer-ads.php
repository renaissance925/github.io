<?php
/**
 * Add the footer section
 */
Themecountry_Kirki::add_section( 'superclick_ads_section', array(
	'title'      		=> esc_attr__( 'Ad Managment', 'superclick' ),
	'panel'				=> 'superclick_options_panel',
	'priority'   		=> 7,
) );

//I. Check to show banner
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        => 'multicheck',
	'settings'    => 'position_ads_under_navigation',
	'label'       => esc_attr__( 'Choose Where to Show:', 'superclick' ),
	'section'     => 'superclick_ads_section',
	'default'     => array('home', 'single_post'),
	'priority'    => 1,
	'choices'     => array(
		'home'				=> esc_attr__( 'Home Page', 'superclick' ),
		'single_post' 		=> esc_attr__( 'Single Post', 'superclick' ),
		'archive'			=> esc_attr__( 'Archive Page(Tags, Dates, Author...)', 'superclick' ),
		'single_page'		=> esc_attr__( 'Single Page', 'superclick' ),
	),
) );

// II. Ads Under Navigation
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'showhide_ads_under_navigation',
	'label'    			=> __( 'Ads Under Navigation', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'switch',
	'default'     		=> 0,
	'priority' 			=> 1,
) );

Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_under_navigation',
	'label'    			=> false,
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'cutom-code',
	'sanitize_callback'	=> 'superclick_sanitize_textarea_code',
	'priority' 			=> 1,
	'active_callback'	=> array(
			array(
				'setting'  => 'showhide_ads_under_navigation',
				'operator' => '==',
				'value'    => 1,
			)
		)
) );

// III. Ads Above Footer
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'showhide_ads_above_footer',
	'label'    			=> __( 'Ads Above Footer', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'switch',
	'default'     		=> 0,
	'priority' 			=> 1,
) );

Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_above_footer',
	'label'    			=> false,
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'cutom-code',
	'sanitize_callback'	=> 'superclick_sanitize_textarea_code',
	'priority' 			=> 1,
	'active_callback'	=> array(
			array(
				'setting'  => 'showhide_ads_above_footer',
				'operator' => '==',
				'value'    => 1,
			)
		)
) );

// Beginning of Post
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_beginning_of_post_enable',
	'label'    			=> __( 'Beginning of Post', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'switch',
	'default'     		=> true,
	'priority' 			=> 1,
) );

Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'select',
	'settings'    		=> 'ads_beginning_of_post',
	'label'       		=> false,
	'section'     		=> 'superclick_ads_section',
	'default'     		=> 'ads_code1',
	'priority'    		=> 1,
	'multiple'    		=> 1,
	'choices'     		=> array(
		'random' 					=> esc_attr__( 'Random Ads', 'superclick' ),
		'ads_code1' 				=> esc_attr__( 'Ads1', 'superclick' ),
		'ads_code2' 				=> esc_attr__( 'Ads2', 'superclick' ),
		'ads_code3' 				=> esc_attr__( 'Ads3', 'superclick' ),
		'ads_code4' 				=> esc_attr__( 'Ads4', 'superclick' ),
		'ads_code5' 				=> esc_attr__( 'Ads5', 'superclick' ),
		'ads_code6' 				=> esc_attr__( 'Ads6', 'superclick' ),
		'ads_code7' 				=> esc_attr__( 'Ads7', 'superclick' ),
		'ads_code8' 				=> esc_attr__( 'Ads8', 'superclick' ),
		'ads_code9' 				=> esc_attr__( 'Ads9', 'superclick' ),
		'ads_code10' 				=> esc_attr__( 'Ads10', 'superclick' ),
	),
	'active_callback'	=> array(
			array(
				'setting'  => 'ads_beginning_of_post_enable',
				'operator' => '==',
				'value'    => true,
			)
		)
) );

// Middle of Post
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_middle_of_post_enable',
	'label'    			=> __( 'Middle of Post', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'switch',
	'default'     		=> false,
	'priority' 			=> 1,
) );

Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'select',
	'settings'   		=> 'ads_middle_of_post',
	'label'       		=> false,
	'section'     		=> 'superclick_ads_section',
	'default'     		=> 'ads_code2',
	'priority'    		=> 1,
	'multiple'    		=> 1,
	'choices'     		=> array(
		'random' 					=> esc_attr__( 'Random Ads', 'superclick' ),
		'ads_code1' 				=> esc_attr__( 'Ads1', 'superclick' ),
		'ads_code2' 				=> esc_attr__( 'Ads2', 'superclick' ),
		'ads_code3' 				=> esc_attr__( 'Ads3', 'superclick' ),
		'ads_code4' 				=> esc_attr__( 'Ads4', 'superclick' ),
		'ads_code5' 				=> esc_attr__( 'Ads5', 'superclick' ),
		'ads_code6' 				=> esc_attr__( 'Ads6', 'superclick' ),
		'ads_code7' 				=> esc_attr__( 'Ads7', 'superclick' ),
		'ads_code8' 				=> esc_attr__( 'Ads8', 'superclick' ),
		'ads_code9' 				=> esc_attr__( 'Ads9', 'superclick' ),
		'ads_code10' 				=> esc_attr__( 'Ads10', 'superclick' ),
	),
	'active_callback'	=> array(
			array(
				'setting'  => 'ads_middle_of_post_enable',
				'operator' => '==',
				'value'    => true,
			)
		)
) );

// End of Post
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_end_of_post_enable',
	'label'    			=> __( 'End of Post', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'switch',
	'default'     		=> true,
	'priority' 			=> 1,
) );

Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'select',
	'settings'    		=> 'ads_end_of_post',
	'label'       		=> false,
	'section'     		=> 'superclick_ads_section',
	'default'     		=> 'ads_code3',
	'priority'    		=> 1,
	'multiple'    		=> 1,
	'choices'     		=> array(
		'random' 					=> esc_attr__( 'Random Ads', 'superclick' ),
		'ads_code1' 				=> esc_attr__( 'Ads1', 'superclick' ),
		'ads_code2'	 				=> esc_attr__( 'Ads2', 'superclick' ),
		'ads_code3' 				=> esc_attr__( 'Ads3', 'superclick' ),
		'ads_code4' 				=> esc_attr__( 'Ads4', 'superclick' ),
		'ads_code5' 				=> esc_attr__( 'Ads5', 'superclick' ),
		'ads_code6' 				=> esc_attr__( 'Ads6', 'superclick' ),
		'ads_code7' 				=> esc_attr__( 'Ads7', 'superclick' ),
		'ads_code8' 				=> esc_attr__( 'Ads8', 'superclick' ),
		'ads_code9' 				=> esc_attr__( 'Ads9', 'superclick' ),
		'ads_code10' 				=> esc_attr__( 'Ads10', 'superclick' ),
	),
	'active_callback'	=> array(
			array(
				'setting'  => 'ads_end_of_post_enable',
				'operator' => '==',
				'value'    => true,
			)
		)
) );

// After Paragraph 1
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_after_paragraph_enable1',
	'label'    			=> __( 'After Paragraph 1', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'switch',
	'default'     		=> false,
	'priority' 			=> 1,
) );

Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'select',
	'settings'    		=> 'ads_after_paragraph1',
	'label'       		=> false,
	'section'    	 	=> 'superclick_ads_section',
	'default'     		=> 'random',
	'priority'    		=> 1,
	'multiple'    		=> 1,
	'choices'     		=> array(
		'random' 					=> esc_attr__( 'Random Ads', 'superclick' ),
		'ads_code1' 				=> esc_attr__( 'Ads1', 'superclick' ),
		'ads_code2' 				=> esc_attr__( 'Ads2', 'superclick' ),
		'ads_code3' 				=> esc_attr__( 'Ads3', 'superclick' ),
		'ads_code4' 				=> esc_attr__( 'Ads4', 'superclick' ),
		'ads_code5' 				=> esc_attr__( 'Ads5', 'superclick' ),
		'ads_code6' 				=> esc_attr__( 'Ads6', 'superclick' ),
		'ads_code7' 				=> esc_attr__( 'Ads7', 'superclick' ),
		'ads_code8' 				=> esc_attr__( 'Ads8', 'superclick' ),
		'ads_code9' 				=> esc_attr__( 'Ads9', 'superclick' ),
		'ads_code10' 				=> esc_attr__( 'Ads10', 'superclick' ),
	),
	'active_callback'	=> array(
			array(
				'setting'  => 'ads_after_paragraph_enable1',
				'operator' => '==',
				'value'    => true,
			)
		)
) );

Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_after_paragraph_num1',
	'description'    	=> __( 'After Paragraph', 'superclick' ),
	'label'				=> false,
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'number',
	'default'			=> 1,
	'priority' 			=> 1,
	'active_callback'	=> array(
			array(
				'setting'  => 'ads_after_paragraph_enable1',
				'operator' => '==',
				'value'    => true,
			)
		)
) );

// After Paragraph 2
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_after_paragraph_enable2',
	'label'    			=> __( 'After Paragraph 2', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'switch',
	'default'     		=> false,
	'priority' 			=> 1,
) );

Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'select',
	'settings'    		=> 'ads_after_paragraph2',
	'label'       		=> false,
	'section'     		=> 'superclick_ads_section',
	'default'     		=> 'random',
	'priority'    		=> 1,
	'multiple'    		=> 1,
	'choices'     		=> array(
		'random' 					=> esc_attr__( 'Random Ads', 'superclick' ),
		'ads_code1' 				=> esc_attr__( 'Ads1', 'superclick' ),
		'ads_code2' 				=> esc_attr__( 'Ads2', 'superclick' ),
		'ads_code3' 				=> esc_attr__( 'Ads3', 'superclick' ),
		'ads_code4' 				=> esc_attr__( 'Ads4', 'superclick' ),
		'ads_code5' 				=> esc_attr__( 'Ads5', 'superclick' ),
		'ads_code6' 				=> esc_attr__( 'Ads6', 'superclick' ),
		'ads_code7' 				=> esc_attr__( 'Ads7', 'superclick' ),
		'ads_code8' 				=> esc_attr__( 'Ads8', 'superclick' ),
		'ads_code9' 				=> esc_attr__( 'Ads9', 'superclick' ),
		'ads_code10' 				=> esc_attr__( 'Ads10', 'superclick' ),
	),
	'active_callback'	=> array(
			array(
				'setting'  => 'ads_after_paragraph_enable2',
				'operator' => '==',
				'value'    => true,
			)
		)
) );

Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_after_paragraph_num2',
	'description'    	=> __( 'After Paragraph', 'superclick' ),
	'label'				=> false,
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'number',
	'default'			=> 1,
	'priority' 			=> 2,
	'active_callback'	=> array(
			array(
				'setting'  => 'ads_after_paragraph_enable2',
				'operator' => '==',
				'value'    => true,
			)
		)
) );

// After Paragraph 3
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_after_paragraph_enable3',
	'label'    			=> __( 'After Paragraph 3', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'switch',
	'default'     		=> false,
	'priority' 			=> 1,
) );

Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'select',
	'settings'    		=> 'ads_after_paragraph3',
	'label'       		=> false,
	'section'     		=> 'superclick_ads_section',
	'default'     		=> 'random',
	'priority'    		=> 1,
	'multiple'    		=> 1,
	'choices'     		=> array(
		'random' 					=> esc_attr__( 'Random Ads', 'superclick' ),
		'ads_code1' 				=> esc_attr__( 'Ads1', 'superclick' ),
		'ads_code2' 				=> esc_attr__( 'Ads2', 'superclick' ),
		'ads_code3' 				=> esc_attr__( 'Ads3', 'superclick' ),
		'ads_code4' 				=> esc_attr__( 'Ads4', 'superclick' ),
		'ads_code5' 				=> esc_attr__( 'Ads5', 'superclick' ),
		'ads_code6' 				=> esc_attr__( 'Ads6', 'superclick' ),
		'ads_code7' 				=> esc_attr__( 'Ads7', 'superclick' ),
		'ads_code8' 				=> esc_attr__( 'Ads8', 'superclick' ),
		'ads_code9' 				=> esc_attr__( 'Ads9', 'superclick' ),
		'ads_code10' 				=> esc_attr__( 'Ads10', 'superclick' ),
	),
	'active_callback'	=> array(
			array(
				'setting'  => 'ads_after_paragraph_enable3',
				'operator' => '==',
				'value'    => true,
			)
		)
) );

Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_after_paragraph_num3',
	'description'    	=> __( 'After Paragraph', 'superclick' ),
	'label'				=> false,
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'number',
	'default'			=> 3,
	'priority' 			=> 1,
	'active_callback'	=> array(
			array(
				'setting'  	=> 'ads_after_paragraph_enable3',
				'operator' 	=> '==',
				'value'    	=> true,
			)
		)
) );

// Ads Appearance
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'multicheck',
	'settings'   		=> 'ads_appearance',
	'label'       		=> esc_attr__( 'Appearance', 'superclick' ),
	'section'    		=> 'superclick_ads_section',
	'default'     		=> array('ad-post', 'ad-page'),
	'priority'    		=> 1,
	'choices'     		=> array(
		'ad-post' 			=> esc_attr__( 'Post', 'superclick' ),
		'ad-page' 			=> esc_attr__( 'Page', 'superclick' ),
		'hide-ad-logg-in' 	=> esc_attr__( 'Hide Ads when user is logged in', 'superclick' ),
	),
) );

// Show ads on article older than [n] days
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'show_ad_age',
	'label'    			=> __( 'Show ads on article older than [n] days', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'number',
	'default'			=> 0,
	'priority' 			=> 1,
) );

// Ads code description
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'custom',
	'settings'    		=> 'ad_code_desc',
	'label'       		=> __( 'Ads Codes', 'superclick' ),
	'section'     		=> 'superclick_ads_section',
	'default'     		=> '<div class="tc-cutomizer-desc">' . __( 'Paste up to <b>10 Ads codes</b> on Post Body as assigned above', 'superclick' ) . '</div>',
	'priority'    		=> 1,
) );

// Ads Code 1
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_code1',
	'label'    			=> __( 'Ads1', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'cutom-code',
	'sanitize_callback'	=> 'superclick_sanitize_textarea_code',
	'priority' 			=> 1,
) );
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'select',
	'settings'    		=> 'alignment_ads_code1',
	'label'       		=> false,
	'description'		=> __( 'Ad alignment', 'superclick' ),
	'section'     		=> 'superclick_ads_section',
	'default'     		=> 'ad-center',
	'priority'    		=> 1,
	'multiple'    		=> 1,
	'choices'     		=> array(
		'ad-left' 			=> esc_attr__( 'Left', 'superclick' ),
		'ad-center' 		=> esc_attr__( 'Center', 'superclick' ),
		'ad-right' 			=> esc_attr__( 'Right', 'superclick' ),
		'ad-none' 			=> esc_attr__( 'None', 'superclick' ),
	),
) );

// Ads Code 2
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_code2',
	'label'    			=> __( 'Ads2', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'cutom-code',
	'sanitize_callback'	=> 'superclick_sanitize_textarea_code',
	'priority' 			=> 1,
) );
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'select',
	'settings'    		=> 'alignment_ads_code2',
	'label'       		=> false,
	'description'		=> __( 'Ad alignment', 'superclick' ),
	'section'     		=> 'superclick_ads_section',
	'default'     		=> 'ad-center',
	'priority'    		=> 1,
	'multiple'    		=> 1,
	'choices'     		=> array(
		'ad-left' 			=> esc_attr__( 'Left', 'superclick' ),
		'ad-center' 		=> esc_attr__( 'Center', 'superclick' ),
		'ad-right' 			=> esc_attr__( 'Right', 'superclick' ),
		'ad-none' 			=> esc_attr__( 'None', 'superclick' ),
	),
) );

// Ads Code 3
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_code3',
	'label'    			=> __( 'Ads3', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'cutom-code',
	'sanitize_callback'	=> 'superclick_sanitize_textarea_code',
	'priority' 			=> 1,
) );
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'select',
	'settings'    		=> 'alignment_ads_code3',
	'label'       		=> false,
	'description'		=> __( 'Ad alignment', 'superclick' ),
	'section'     		=> 'superclick_ads_section',
	'default'     		=> 'ad-center',
	'priority'    		=> 1,
	'multiple'    		=> 1,
	'choices'     		=> array(
		'ad-left' 			=> esc_attr__( 'Left', 'superclick' ),
		'ad-center' 		=> esc_attr__( 'Center', 'superclick' ),
		'ad-right' 			=> esc_attr__( 'Right', 'superclick' ),
		'ad-none' 			=> esc_attr__( 'None', 'superclick' ),
	),
) );

// Ads Code 4
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_code4',
	'label'    			=> __( 'Ads4', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'cutom-code',
	'sanitize_callback'	=> 'superclick_sanitize_textarea_code',
	'priority' 			=> 1,
) );
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'select',
	'settings'    		=> 'alignment_ads_code4',
	'label'       		=> false,
	'description'		=> __( 'Ad alignment', 'superclick' ),
	'section'     		=> 'superclick_ads_section',
	'default'     		=> 'ad-center',
	'priority'    		=> 1,
	'multiple'    		=> 1,
	'choices'     		=> array(
		'ad-left' 			=> esc_attr__( 'Left', 'superclick' ),
		'ad-center' 		=> esc_attr__( 'Center', 'superclick' ),
		'ad-right' 			=> esc_attr__( 'Right', 'superclick' ),
		'ad-none' 			=> esc_attr__( 'None', 'superclick' ),
	),
) );

// Ads Code 5
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_code5',
	'label'    			=> __( 'Ads5', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'cutom-code',
	'sanitize_callback'	=> 'superclick_sanitize_textarea_code',
	'priority' 			=> 1,
) );
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'select',
	'settings'    		=> 'alignment_ads_code5',
	'label'       		=> false,
	'description'		=> __( 'Ad alignment', 'superclick' ),
	'section'     		=> 'superclick_ads_section',
	'default'     		=> 'ad-center',
	'priority'    		=> 1,
	'multiple'    		=> 1,
	'choices'     		=> array(
		'ad-left' 			=> esc_attr__( 'Left', 'superclick' ),
		'ad-center' 		=> esc_attr__( 'Center', 'superclick' ),
		'ad-right' 			=> esc_attr__( 'Right', 'superclick' ),
		'ad-none' 			=> esc_attr__( 'None', 'superclick' ),
	),
) );

// Ads Code 6
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_code6',
	'label'    			=> __( 'Ads6', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'cutom-code',
	'sanitize_callback'	=> 'superclick_sanitize_textarea_code',
	'priority' 			=> 1,
) );
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'select',
	'settings'    		=> 'alignment_ads_code6',
	'label'       		=> false,
	'description'		=> __( 'Ad alignment', 'superclick' ),
	'section'     		=> 'superclick_ads_section',
	'default'     		=> 'ad-center',
	'priority'    		=> 1,
	'multiple'    		=> 1,
	'choices'     		=> array(
		'ad-left' 			=> esc_attr__( 'Left', 'superclick' ),
		'ad-center' 		=> esc_attr__( 'Center', 'superclick' ),
		'ad-right' 			=> esc_attr__( 'Right', 'superclick' ),
		'ad-none' 			=> esc_attr__( 'None', 'superclick' ),
	),
) );

// Ads Code 7
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_code7',
	'label'    			=> __( 'Ads7', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'cutom-code',
	'sanitize_callback'	=> 'superclick_sanitize_textarea_code',
	'priority' 			=> 1,
) );
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'select',
	'settings'    		=> 'alignment_ads_code7',
	'label'       		=> false,
	'description'		=> __( 'Ad alignment', 'superclick' ),
	'section'     		=> 'superclick_ads_section',
	'default'     		=> 'ad-center',
	'priority'    		=> 1,
	'multiple'    		=> 1,
	'choices'     		=> array(
		'ad-left' 			=> esc_attr__( 'Left', 'superclick' ),
		'ad-center' 		=> esc_attr__( 'Center', 'superclick' ),
		'ad-right' 			=> esc_attr__( 'Right', 'superclick' ),
		'ad-none' 			=> esc_attr__( 'None', 'superclick' ),
	),
) );

// Ads Code 8
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_code8',
	'label'    			=> __( 'Ads8', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'cutom-code',
	'sanitize_callback'	=> 'superclick_sanitize_textarea_code',
	'priority' 			=> 1,
) );
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'select',
	'settings'    		=> 'alignment_ads_code8',
	'label'       		=> false,
	'description'		=> __( 'Ad alignment', 'superclick' ),
	'section'     		=> 'superclick_ads_section',
	'default'     		=> 'ad-center',
	'priority'    		=> 1,
	'multiple'    		=> 1,
	'choices'     		=> array(
		'ad-left' 			=> esc_attr__( 'Left', 'superclick' ),
		'ad-center' 		=> esc_attr__( 'Center', 'superclick' ),
		'ad-right' 			=> esc_attr__( 'Right', 'superclick' ),
		'ad-none' 			=> esc_attr__( 'None', 'superclick' ),
	),
) );

// Ads Code 9
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_code9',
	'label'    			=> __( 'Ads9', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'cutom-code',
	'sanitize_callback'	=> 'superclick_sanitize_textarea_code',
	'priority' 			=> 1,
) );
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'select',
	'settings'    		=> 'alignment_ads_code9',
	'label'       		=> false,
	'description'		=> __( 'Ad alignment', 'superclick' ),
	'section'     		=> 'superclick_ads_section',
	'default'     		=> 'ad-center',
	'priority'    		=> 1,
	'multiple'    		=> 1,
	'choices'     		=> array(
		'ad-left' 			=> esc_attr__( 'Left', 'superclick' ),
		'ad-center' 		=> esc_attr__( 'Center', 'superclick' ),
		'ad-right' 			=> esc_attr__( 'Right', 'superclick' ),
		'ad-none' 			=> esc_attr__( 'None', 'superclick' ),
	),
) );

// Ads Code 10
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'settings' 			=> 'ads_code10',
	'label'    			=> __( 'Ads10', 'superclick' ),
	'section'  			=> 'superclick_ads_section',
	'type'     			=> 'cutom-code',
	'sanitize_callback'	=> 'superclick_sanitize_textarea_code',
	'priority' 			=> 1,
) );
Themecountry_Kirki::add_field( 'superclick_theme_conf', array(
	'type'        		=> 'select',
	'settings'    		=> 'alignment_ads_code10',
	'label'       		=> false,
	'description'		=> __( 'Ad alignment', 'superclick' ),
	'section'     		=> 'superclick_ads_section',
	'default'     		=> 'ad-center',
	'priority'    		=> 1,
	'multiple'    		=> 1,
	'choices'     		=> array(
		'ad-left' 			=> esc_attr__( 'Left', 'superclick' ),
		'ad-center' 		=> esc_attr__( 'Center', 'superclick' ),
		'ad-right' 			=> esc_attr__( 'Right', 'superclick' ),
		'ad-none' 			=> esc_attr__( 'None', 'superclick' ),
	),
) );