<?php


/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function superclick_customize_register( $wp_customize ) {

	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

}
add_action( 'customize_register', 'superclick_customize_register' );

/**
 * Embed JS file for Customizer Controls
 *
 */
function superclick_customize_controls_js() {
	
	wp_enqueue_script( 'superclick-customizer-controls', get_template_directory_uri() . '/inc/customizer/assets/js/customizer-controls.js', array(), '20160530', true );
	
	// Localize the script
	wp_localize_script( 'superclick-customizer-controls', 'superclick_theme_links', array(
		'title'	=> esc_html__( 'Theme Links', 'superclick' ),
		'themeURL'	=> esc_url( __( 'https://themecountry.com/themes/superclick/', 'superclick' ) . '?utm_source=customizer&utm_medium=textlink&utm_campaign=superclick&utm_content=theme-page' ),
		'themeLabel'	=> esc_html__( 'Theme Page', 'superclick' ),
		'docuURL'	=> esc_url( __( 'https://themecountry.com/docs/superclick-documentation/', 'superclick' ) . '?utm_source=customizer&utm_medium=textlink&utm_campaign=superclick&utm_content=documentation' ),
		'docuLabel'	=>  esc_html__( 'Theme Documentation', 'superclick' ),
		'rateURL'	=> esc_url( 'http://wordpress.org/support/view/theme-reviews/superclick?filter=5' ),
		'rateLabel'	=> esc_html__( 'Rate this theme', 'superclick' ),
		)
	);

}
add_action( 'customize_controls_enqueue_scripts', 'superclick_customize_controls_js' );

/**
 * Embed CSS styles for the theme options in the Customizer
 *
 */
function superclick_customize_preview_css() {
	wp_enqueue_style( 'superclick-customizer-css', get_template_directory_uri() . '/inc/customizer/assets/css/customizer.css', array(), '20160530' );
}

add_action( 'customize_controls_print_styles', 'superclick_customize_preview_css' );

/**
 * Add the theme configuration
 */
Themecountry_Kirki::add_config( 'superclick_theme_conf', array(
	'option_type' => 'option',
	'option_name' => 'superclick_theme_options',
	'capability'  => 'edit_theme_options',
) );

/**
 * Theme Options Panel
 */

Themecountry_Kirki::add_panel( 'superclick_options_panel', array(
    'priority'       => 200,
    'title'       => __( 'Theme Options', 'superclick' )
) );

/**
 * Returns theme options
 *
 * Uses sane defaults in case the user has not configured any theme options yet.
 */
function superclick_theme_options() {
	// Merge Theme Options Array from Database with Default Options Array
	$theme_options = wp_parse_args( 
		
		// Get saved theme options from WP database
		get_option( 'superclick_theme_options', array() ), 
		
		// Merge with Default Options if setting was not saved yet
		superclick_default_options() 
		
	);

	// Return theme options
	return $theme_options;
}

/**
 * Returns the default settings of the theme
 *
 * @return array
 */
function superclick_default_options() {

	$default_options = array(
		'post_layout_archives'				=> 'left',
		'post_layout_single' 				=> 'header',
		'pagination_type'					=> 'default',

		//General Option
		'site_title'						=> true,
		'custom_super_click_layout'			=> 'custom-layout',
		'sidebar_layout' 					=> 'right-sidebar',
		'sticky_header'						=> false,
		'post_layout_style'					=> 'post-list',
		'post_content' 						=> 'excerpt',
		'excerpt_length' 					=> 40,
		'excerpt_more' 						=> ' [...]',
		'read_more_button'					=> true,
		'back_to_top'						=> true,
		'header_code'						=> '',
		'footer_code'						=> '',
		'post_meta_info'					=> array('meta-author', 'meta-date', 'meta-tag', 'meta-category'),
		'paging'							=> 'paging-default',

		//Default Color & Style
		'primary_color'						=> '#ececec',
		'custom_default_color'				=> false,

		//Single
		'breadscrumb_yoast_seo'				=> false,
		'breadscrumb'						=> false,
		'featured_post_single_page'			=> false,
		'post_nav'							=> true,
		'author_bio'						=> true,
		'related_posts'						=> true,
		'related_post_display_style'		=> 'grid',
		'number_related_post'				=> 6,
		'related_post_taxonomy'				=> 'cat',
		'date_related'						=> true,
		'comment_related'					=> true,

		//Social Share
		'social_sharing_button'				=> true,
		'enable_social_sharing_button'		=> array('twitter', 'facebook', 'googleplus'),
		'twitter_username'					=> '',
		'sharing_button_position'			=> array( 'sticky-left' ),

		//Footer
		'footer_widget_col'					=> 'three-col',
		'footer_copyright_text'				=> '',

		// Add Management
		'showhide_ads_under_navigation'		=> '0',
		'ads_under_navigation'				=> '',
		'showhide_ads_above_footer'			=> '0',
		'ads_above_footer'					=> '',
		'position_ads_under_navigation'		=> array('home', 'single_post'),

		'ads_appearance'					=> array('ad-post', 'ad-page'),
		'show_ad_age'						=> '',
		'ads_beginning_of_post_enable'		=> true,
		'ads_middle_of_post_enable'			=> false,
		'ads_end_of_post_enable'			=> true,
		'ads_after_paragraph_enable1'		=> false,
		'ads_after_paragraph_enable2'		=> false,
		'ads_after_paragraph_enable3'		=> false,
		'ads_beginning_of_post'				=> '',
		'ads_middle_of_post'				=> '',
		'ads_end_of_post'					=> '',
		'ads_after_paragraph1'				=> '',
		'ads_after_paragraph2'				=> '',
		'ads_after_paragraph3'				=> '',
		'ads_code1'							=> '',
		'ads_code2'							=> '',
		'ads_code3'							=> '',
		'ads_code4'							=> '',
		'ads_code5'							=> '',
		'ads_code6'							=> '',
		'ads_code7'							=> '',
		'ads_code8'							=> '',
		'ads_code9'							=> '',
		'ads_code10'						=> '',
		'random'							=> '',
	);
	
	return $default_options;
}
/**
 * Get single theme option
 */

function superclick_get_option( $setting, $default ) {
    $options = get_option( 'superclick_theme_options', array() );
    $value = $default;
    if ( isset( $options[ $setting ] ) ) {
        $value = $options[ $setting ];
    }
    return $value;
}

// Customizer Asset Path
$asset_customizer_path = get_template_directory_uri() .'/inc/customizer/assets';

// Load Customizer Function Files
require( get_template_directory() . '/inc/customizer/functions/custom-controls.php' );
require( get_template_directory() . '/inc/customizer/functions/sanitize-functions.php' );
require( get_template_directory() . '/inc/customizer/functions/ads-management.php' );

// Load Customizer Section Files
require( get_template_directory() . '/inc/customizer/sections/customizer-general.php' );
require( get_template_directory() . '/inc/customizer/sections/customizer-style.php' );
require( get_template_directory() . '/inc/customizer/sections/customizer-socials.php' );
require( get_template_directory() . '/inc/customizer/sections/customizer-footer.php' );
require( get_template_directory() . '/inc/customizer/sections/customizer-single.php' );
require( get_template_directory() . '/inc/customizer/sections/customizer-typography.php' );
require( get_template_directory() . '/inc/customizer/sections/customizer-ads.php' );