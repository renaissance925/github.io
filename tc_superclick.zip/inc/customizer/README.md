USE Customizer
==============

1. Include files into functions.php

/**
 * Customizer additions.
 */
require_once get_template_directory() . '/inc/customizer/class-themecountry-kirki.php';

/**
 * Recommend the Kirki plugin
 */
require get_template_directory() . '/inc/customizer/include-kirki.php';


// include Theme Customizer Options
require get_template_directory() . '/inc/customizer/customizer.php';
