<?php

/*
|
|	Plugin Name: ThemeCountry Facebook Like Box
|	Description: A widget to display Facebook Like Box.
|	Version: 1.1
|
*/


/*
|------------------------------------------------------------------------------
| Load Widgets
|------------------------------------------------------------------------------
*/
add_action('widgets_init', 'facebook_like_box_load_widgets');


/*
 |------------------------------------------------------------------------------
 | Register widget
 |------------------------------------------------------------------------------
 |
 | @return void
 |
 */
function facebook_like_box_load_widgets()
{
	register_widget('superclick_Facebook_Like_Box_Widget');
}

/*
|------------------------------------------------------------------------------
| Facebook Like Box Widget Class
|------------------------------------------------------------------------------
*/
class superclick_Facebook_Like_Box_Widget extends WP_Widget {

	/*
	|------------------------------------------------------------------------------
	| Widget Setup
	|------------------------------------------------------------------------------
	*/
	public function superclick_Facebook_Like_Box_Widget()
	{
		$widget_ops = array(
			'classname' => 'facebook_like', 
			'description' => __('Add Facebook Like Box.','superclick'),
			'title'			=> 'Facebook Like Box'
		);

		$control_ops = array('id_base' => 'tc-facebook-like-box-widget');

		parent::__construct( 'tc-facebook-like-box-widget', __('TC: FB Like Box','superclick'), $widget_ops, $control_ops);
	}

	/*
	|------------------------------------------------------------------------------
	|	Display Widget
	|------------------------------------------------------------------------------
	*/
	public function widget($args, $instance)
	{
		extract($args);

		$title = apply_filters('widget_title', $instance['title']);
		$page_url = $instance['page_url'];
		$width = $instance['width'];
		$color_scheme = $instance['color_scheme'];
		$show_faces = isset($instance['show_faces']) ? "true" : "false";
		$show_stream = isset($instance['show_stream']) ? "true" : "false";
		$show_header = isset($instance['show_header']) ? "true" : "false";
		$show_border = isset($instance['show_border']) ? "true" : "false";

		$height = '65';
		
		if($show_faces == true) {
			$height = '239';
		}
		
		if($show_header == true) {
			$height = '264';
		}

		if($show_stream == true) {
			$height = '600';
		}
		
		echo $before_widget;

		if($title) {
			echo $before_title.$title.$after_title;
		}
		
		if($page_url): ?>
			<div class="fb-like-box" data-href="<?php echo $page_url; ?>" data-show-border="<?php echo $show_border ?>" data-height="<?php echo $height; ?>" data-width="<?php echo $width; ?>" data-colorscheme="<?php echo $color_scheme; ?>" data-show-faces="<?php echo $show_faces; ?>" data-header="<?php echo $show_header; ?>" data-stream="<?php echo $show_stream; ?>" allowTransparency="true" ></div>
		<?php endif;
		
		echo $after_widget;
	}
	
	/*
	|------------------------------------------------------------------------------
	|	Update Widget
	|------------------------------------------------------------------------------
	*/
	public function update($new_instance, $old_instance)
	{
		$instance = $old_instance;

		$instance['title'] = strip_tags($new_instance['title']);
		$instance['page_url'] = $new_instance['page_url'];
		$instance['width'] = $new_instance['width'];
		$instance['color_scheme'] = $new_instance['color_scheme'];
		$instance['show_faces'] = $new_instance['show_faces'];
		$instance['show_stream'] = $new_instance['show_stream'];
		$instance['show_header'] = $new_instance['show_header'];
		$instance['show_border'] = $new_instance['show_border'];
		
		return $instance;
	}

	/*
	|------------------------------------------------------------------------------
	|	Form Widget
	|------------------------------------------------------------------------------
	*/
	public function form($instance)
	{
		$defaults = array('title' => __('Find us on Facebook','superclick'), 'page_url' => '', 'width' => '292', 'color_scheme' => 'light', 'show_faces' => 'on', 'show_stream' => 'false', 'show_header' => 'false', 'show_border' => 'true');
		$instance = wp_parse_args((array) $instance, $defaults); ?>
		
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title','superclick'); ?>:</label>
			<input type="text" class="widefat" style="width: 216px;" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $instance['title']; ?>" />
		</p>
		
		<p>
			<label for="<?php echo $this->get_field_id('page_url'); ?>"><?php _e('Facebook Page URL','superclick'); ?>:</label>
			<input type="text" class="widefat" style="width: 216px;" id="<?php echo $this->get_field_id('page_url'); ?>" name="<?php echo $this->get_field_name('page_url'); ?>" value="<?php echo $instance['page_url']; ?>" />
		</p>
		
		<p>
			<label for="<?php echo $this->get_field_id('width'); ?>"><?php _e('Width','superclick'); ?>:</label>
			<input type="text" class="widefat" style="width: 40px;" id="<?php echo $this->get_field_id('width'); ?>" name="<?php echo $this->get_field_name('width'); ?>" value="<?php echo $instance['width']; ?>" />
		</p>
		
		<p>
			<label for="<?php echo $this->get_field_id('color_scheme'); ?>"><?php _e('Color Scheme','superclick'); ?>:</label> 
			<select id="<?php echo $this->get_field_id('color_scheme'); ?>" name="<?php echo $this->get_field_name('color_scheme'); ?>" style="width:100%;">
				<option <?php if ('light' == $instance['color_scheme']) echo 'selected="selected"'; ?>><?php _e('light','superclick'); ?></option>
				<option <?php if ('dark' == $instance['color_scheme']) echo 'selected="selected"'; ?>><?php _e('dark','superclick'); ?></option>
			</select>
		</p>
		
		<p>
			<input class="checkbox" type="checkbox" <?php checked($instance['show_faces'], 'on'); ?> id="<?php echo $this->get_field_id('show_faces'); ?>" name="<?php echo $this->get_field_name('show_faces'); ?>" /> 
			<label for="<?php echo $this->get_field_id('show_faces'); ?>"><?php _e('Show Faces','superclick'); ?></label>
		</p>
		
		<p>
			<input class="checkbox" type="checkbox" <?php checked($instance['show_stream'], 'on'); ?> id="<?php echo $this->get_field_id('show_stream'); ?>" name="<?php echo $this->get_field_name('show_stream'); ?>" /> 
			<label for="<?php echo $this->get_field_id('show_stream'); ?>"><?php _e('Show Stream','superclick'); ?></label>
		</p>
		
		<p>
			<input class="checkbox" type="checkbox" <?php checked($instance['show_header'], 'on'); ?> id="<?php echo $this->get_field_id('show_header'); ?>" name="<?php echo $this->get_field_name('show_header'); ?>" /> 
			<label for="<?php echo $this->get_field_id('show_header'); ?>"><?php _e('Show Facebook Header','superclick'); ?></label>
		</p>
		<p>
			<input class="checkbox" type="checkbox" <?php checked($instance['show_border'], 'on'); ?> id="<?php echo $this->get_field_id('show_border'); ?>" name="<?php echo $this->get_field_name('show_border'); ?>" /> 
			<label for="<?php echo $this->get_field_id('show_border'); ?>"><?php _e('Show Border','superclick'); ?></label>
		</p>
	<?php
	}
}
?>