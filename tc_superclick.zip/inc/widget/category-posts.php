<?php
/*
|
|	Plugin Name: superclick Category  Posts
|	Description: A widget to display Category's Posts.
|	Version: 1.0
|
*/

/*
|------------------------------------------------------------------------------
| Category Posts Widget Class
|------------------------------------------------------------------------------
*/

class superclick_recent_tweets_Widget extends WP_Widget {


	/*
	|------------------------------------------------------------------------------
	| Widget Setup
	|------------------------------------------------------------------------------
	|
	| @return void
	|
	*/
	public function superclick_recent_tweets_Widget() {
		$widget_ops = array(
			'classname' 		=> 'custom-widget superclick-category-posts-widget', 
			'description' 		=> __('superclick Category Posts.','superclick'),
			'widget_title'		=> 'Category Posts'
		);

		$control_ops = array(
			'id_base' => 'superclick-category-posts'
		);

		parent::__construct( 'superclick-category-posts', __('TC1: Category Posts','superclick'), $widget_ops, $control_ops);
	}

	/*
	|------------------------------------------------------------------------------
	| Display Widget
	|------------------------------------------------------------------------------
	|
	| @return void
	|
	*/
	public function widget( $args, $instance ) {
		extract( $args );

		$title = apply_filters( 'widget_title', isset( $instance['title'] ) ? $instance['title'] : 'Category Posts' );
		$cat = isset( $instance['cat'] ) ? $instance['cat'] : '';
		$comment_num = isset( $instance['comment_num'] ) ? $instance['comment_num'] : '1';
		$date = isset( $instance['date'] ) ? $instance['date'] : '1';
		$qty = (int) isset( $instance['qty'] ) ? $instance['qty'] : '5';
		$show_thumbnail_4 = (int) isset( $instance['show_thumbnail_4'] ) ? $instance['show_thumbnail_4'] : '1';
		$show_excerpt = isset( $instance['show_excerpt'] ) ? $instance['show_excerpt'] : '1' ;
		$excerpt_length = isset( $instance['excerpt_length'] ) ? $instance['excerpt_length'] : '10';
		

		echo $before_widget;
		if ( ! empty( $title ) ) {
			echo $before_title . $title . $after_title;
		}

		echo self::tc_get_category_posts($cat, $qty, $comment_num, $date, $show_thumbnail_4, $show_excerpt, $excerpt_length );
		echo $after_widget;
		

	}
    /*
	|------------------------------------------------------------------------------
	| Update Widget
	|------------------------------------------------------------------------------
	|
	| @return void
	|
	*/
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['cat'] = intval( $new_instance['cat'] );
		$instance['qty'] = intval( $new_instance['qty'] );
		$instance['comment_num'] = intval( $new_instance['comment_num'] );
		$instance['date'] = intval( $new_instance['date'] );
		$instance['show_thumbnail_4'] = intval( $new_instance['show_thumbnail_4'] );
		$instance['show_excerpt'] = intval( $new_instance['show_excerpt'] );
		$instance['excerpt_length'] = intval( $new_instance['excerpt_length'] );
		return $instance;
	}

	/*
	|------------------------------------------------------------------------------
	| Widget Settings 
	|------------------------------------------------------------------------------
	|
	| Displays the widget settings controls on the widget panel
	| 
	| @return void
	|
	*/
 	public function form( $instance ) {
		$defaults = array(
			'comment_num' => 1,
			'date' => 1,
			'show_thumbnail_4' => 1,
			'show_excerpt' => 0,
			'excerpt_length' => 10
		);

		$instance = wp_parse_args((array) $instance, $defaults);
		$cat = isset( $instance[ 'cat' ] ) ? esc_attr( $instance[ 'cat' ] ) : false;
		$title = isset( $instance[ 'title' ] ) ? $instance[ 'title' ] : __( 'Category Posts','cleaneadpro' );
		$qty = isset( $instance[ 'qty' ] ) ? esc_attr( $instance[ 'qty' ] ) : 5;
		$comment_num = isset( $instance[ 'comment_num' ] ) ? esc_attr( $instance[ 'comment_num' ] ) : 1;
		$show_excerpt = isset( $instance[ 'show_excerpt' ] ) ? esc_attr( $instance[ 'show_excerpt' ] ) : 1;
		$date = isset( $instance[ 'date' ] ) ? esc_attr( $instance[ 'date' ] ) : 1;
		$excerpt_length = isset( $instance[ 'excerpt_length' ] ) ? intval( $instance[ 'excerpt_length' ] ) : 10;
		$show_thumbnail_4 = isset( $instance[ 'show_thumbnail_4' ] ) ? esc_attr( $instance[ 'show_thumbnail_4' ] ) : 1;
		$show_excerpt = isset( $instance[ 'show_excerpt' ] ) ? esc_attr( $instance[ 'show_excerpt' ] ) : 1;
		$excerpt_length = isset( $instance[ 'excerpt_length' ] ) ? intval( $instance[ 'excerpt_length' ] ) : 10;
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:','superclick' ); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'cat' ); ?>"><?php _e( 'Category:','superclick' ); ?></label> 
			<?php wp_dropdown_categories( Array(
				'orderby'            => 'ID', 
				'order'              => 'ASC',
				'show_count'         => 1,
				'hide_empty'         => 1,
				'hide_if_empty'      => true,
				'echo'               => 1,
				'selected'           => $cat,
				'hierarchical'       => 1, 
				'name'               => $this->get_field_name( 'cat' ),
				'id'                 => $this->get_field_id( 'cat' ),
				'taxonomy'           => 'category',
			) ); ?>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'qty' ); ?>"><?php _e( 'Number of Posts to show','superclick' ); ?></label> 
			<input id="<?php echo $this->get_field_id( 'qty' ); ?>" name="<?php echo $this->get_field_name( 'qty' ); ?>" type="number" min="1" step="1" value="<?php echo $qty; ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id("show_thumbnail_4"); ?>">
				<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("show_thumbnail_4"); ?>" name="<?php echo $this->get_field_name("show_thumbnail_4"); ?>" value="1" <?php if (isset($instance['show_thumbnail_4'])) { checked( 1, $instance['show_thumbnail_4'], true ); } ?> />
				<?php _e( 'Show Thumbnails', 'superclick'); ?>
			</label>
		</p>
		
		<p>
			<label for="<?php echo $this->get_field_id("date"); ?>">
				<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("date"); ?>" name="<?php echo $this->get_field_name("date"); ?>" value="1" <?php checked( 1, $instance['date'], true ); ?> />
				<?php _e( 'Show post date', 'superclick'); ?>
			</label>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id("comment_num"); ?>">
				<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("comment_num"); ?>" name="<?php echo $this->get_field_name("comment_num"); ?>" value="1" <?php checked( 1, $instance['comment_num'], true ); ?> />
				<?php _e( 'Show number of comments', 'superclick'); ?>
			</label>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id("show_excerpt"); ?>">
				<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("show_excerpt"); ?>" name="<?php echo $this->get_field_name("show_excerpt"); ?>" value="1" <?php checked( 1, $instance['show_excerpt'], true ); ?> />
				<?php _e( 'Show excerpt', 'superclick'); ?>
			</label>
		</p>
		
		<p>
	       <label for="<?php echo $this->get_field_id( 'excerpt_length' ); ?>"><?php _e( 'Excerpt Length:', 'superclick' ); ?>
	       <input id="<?php echo $this->get_field_id( 'excerpt_length' ); ?>" name="<?php echo $this->get_field_name( 'excerpt_length' ); ?>" type="number" min="1" step="1" value="<?php echo $excerpt_length; ?>" />
	       </label>
       </p>
	   
		<?php 
	}

	/*
	|------------------------------------------------------------------------------
	| Get Related Posts
	|------------------------------------------------------------------------------
	|
	| To display related posts by user filter
	| 
	| @return void
	|
	*/
	public function tc_get_category_posts($cat, $qty, $comment_num, $date, $show_thumbnail_4, $show_excerpt, $excerpt_length) {

		global $post;
		$thePostID = $post->ID;
	    
		$posts = new WP_Query(
			"cat=".$cat."&orderby=date&order=DESC&posts_per_page=".$qty
			);


		if ($show_thumbnail_4 != 1) :
		 	echo '<ul class="superclick-category-posts no-thumbnail">';
		else :
			echo '<ul class="superclick-category-posts have-thumbnail">';
		endif;
		
		while ( $posts->have_posts() ) : 
		$posts->the_post(); ?>
			<li>
				
				<?php if ( has_post_thumbnail() && $show_thumbnail_4 ) : ?>
					<div class="post-img">
						<a href="<?php the_permalink(); ?>">
						    <?php the_post_thumbnail('superclick-widget-thumb',array('title' => '')); ?>
						</a>
					</div>
				<?php elseif ( !has_post_thumbnail() && $show_thumbnail_4 ) : ?>
					<div class="post-img">
						<a href="<?php the_permalink(); ?>">
						    <img src="<?php echo get_template_directory_uri(); ?>/images/80x80.png" />
						</a>
					</div>
				<?php endif; ?>

				<div class="post-data">
					
					<a href="<?php the_permalink(); ?>" alt="<?php the_title(); ?>"><?php the_title(); ?></a>
					
					<div class="widget-post-meta">
						<?php if ( $date == 1 ) : ?>
							<?php the_time('F j, Y'); ?>,
						<?php endif; ?>

						<?php if ( $date == 1 && $comment_num == 1) : ?>
							
						<?php endif; ?>

						<?php if ( $comment_num == 1 ) : ?>
							<?php echo comments_number(__('No Comment','superclick'), __('One Comment','superclick'), '<span class="comm">%</span> '.__('Comments','superclick'));?>
						<?php endif; ?>
					</div> <!--end .entry-meta-->

					<?php if ( $show_excerpt == 1 ) : ?>
						<p>
							<?php echo superclick_excerpt($excerpt_length); ?>
						</p>
					<?php endif; ?>
				</div>
				<span class="clear"></span>
			</li>
		<?php 
		endwhile;		
		echo '</ul>'."\r\n";
	}

}

/*
|------------------------------------------------------------------------------
| Load Widgets
|------------------------------------------------------------------------------
*/
add_action('widgets_init', 'tc_category_posts_load_widgets');

/*
 |------------------------------------------------------------------------------
 | Register widget
 |------------------------------------------------------------------------------
 |
 | @return void
 |
 */
function tc_category_posts_load_widgets()
{
	register_widget('superclick_recent_tweets_Widget');
}