<?php
/***
 * Magazine Posts Boxed Widget
 *
 * Display the latest posts from a selected category in a boxed layout. 
 * Intented to be used in the Magazine Homepage widget area to built a magazine layouted page.
 *
 * @package Superclick
 */

class tc_Magazine_Posts_Lists_Widget extends WP_Widget {

	/**
	 * Widget Constructor
	 */
	function __construct() {
		
		// Setup Widget
		parent::__construct(
			'tc-magazine-posts-lists', // ID
			sprintf( esc_html__( 'TC: Magazine List', 'superclick' ), wp_get_theme()->Name ), // Name
			array( 
				'classname'		=> 'tc_magazine_posts_lists', 
				'description'	=> esc_html__( 'Add this widgets to appear this style on magazine template.', 'superclick' ),
				'customize_selective_refresh' => true, 
			) // Args
		);

		// Delete Widget Cache on certain actions
		add_action( 'save_post', array( $this, 'delete_widget_cache' ) );
		add_action( 'deleted_post', array( $this, 'delete_widget_cache' ) );
		add_action( 'switch_theme', array( $this, 'delete_widget_cache' ) );
	}
	
	
	/**
	 * Set default settings of the widget
	 */
	private function default_settings() {
	
		$defaults = array(
			'title'				=> '',
			'category'			=> 0,
			'layout'			=> 'left',
			'number'			=> 4,
			'meta_date'			=> true,
			'meta_author'		=> true,
			'meta_author'		=> true,
		);
		
		return $defaults;
		
	}

	
	/**
	 * Main Function to display the widget
	 * 
	 * @uses this->render()
	 * 
	 * @param array $args / Parameters from widget area created with register_sidebar()
	 * @param array $instance / Settings for this widget instance
	 */
	function widget( $args, $instance ) {

		$cache = array();
				
		// Get Widget Object Cache
		if ( ! $this->is_preview() ) {
			$cache = wp_cache_get( 'widget_tc_magazine_posts_lists', 'widget' );
		}
		if ( ! is_array( $cache ) ) {
			$cache = array();
		}

		// Display Widget from Cache if exists
		if ( isset( $cache[ $this->id ] ) ) {
			echo $cache[ $this->id ];
			return;
		}
		
		// Start Output Buffering
		ob_start();

		// Get Widget Settings
		$settings = wp_parse_args( $instance, $this->default_settings() );
		
		// Output
		echo $args['before_widget'];
	?>
		<div class="widget-magazine-posts-lists widget-magazine-posts clearfix">

			<?php // Display Title
			$this->widget_title( $args, $settings ); ?>
			
			<div class="widget-magazine-posts-content">
			
				<?php $this->render( $settings ); ?>
				
			</div>
			
		</div>
	<?php
		echo $args['after_widget'];
		
		// Set Cache
		if ( ! $this->is_preview() ) {
			$cache[ $this->id ] = ob_get_flush();
			wp_cache_set( 'widget_tc_magazine_posts_lists', $cache, 'widget' );
		} else {
			ob_end_flush();
		}
	}
	
	
	/**
	 * Renders the Widget Content
	 *
	 * Switches between horizontal and vertical layout style based on widget settings
	 * 
	 * @uses this->magazine_posts_right_list() or this->magazine_posts_left_list()
	 * @used-by this->widget()
	 *
	 * @param array $instance / Settings for this widget instance
	 */
	function render( $settings ) {
		
		if( 'right' == $settings['layout'] ) : ?>
		
			<div class="magazine-posts-lists clearfix">
			
				<?php $this->magazine_posts_right_list( $settings ); ?>

			</div>

		<?php elseif ( 'full-thumbnail' == $settings['layout'] ) : ?>
			
			<?php $this->magazine_posts_full_thubmnail( $settings ); ?>
		
		
		<?php else: ?>
			
			<div class="magazine-posts-lists clearfix">
			
				<?php $this->magazine_posts_left_list( $settings ); ?>

			</div>
		
		<?php 
		endif;

	}
	
	
	/**
	 * Display Magazine Posts in Horizontal Layout
	 *
	 * @used-by this->render()
	 *
	 * @param array $instance / Settings for this widget instance
	 */
	function magazine_posts_right_list( $settings ) {
		
		// Get latest posts from database
		$query_arguments = array(
			'posts_per_page'		=> (int) $settings['number'],
			'ignore_sticky_posts'	=> true,
			'cat' => (int)$settings['category']
		);
		$posts_query = new WP_Query( $query_arguments );
		$i = 0;

		// Check if there are posts
		if( $posts_query->have_posts() ) :
		
			// Limit the number of words for the excerpt
			add_filter( 'excerpt_length', 'tc_magazine_posts_excerpt_length' );

			// Display Posts
			while( $posts_query->have_posts() ) :
				
				$posts_query->the_post(); ?>

					<article id="post-<?php the_ID(); ?>" <?php post_class( 'right-post list-post post-item clearfix' ); ?>>

						<div class="post-thumbnail">
							<a href="<?php the_permalink() ?>" rel="bookmark" class="featured-thumbnail">

							<?php
							if ( has_post_thumbnail() ) :

								the_post_thumbnail();

							else :
							?>
								
								<img src="<?php echo get_template_directory_uri(); ?>/images/post-thumbnails.jpg" />

							<?php
							endif;
							?>

							</a>
						</div><!-- .post-thumbnail -->

						<div class="entry-content">

							<header class="entry-header">
								
								<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
								<?php $this->entry_meta( $settings ); ?>

							</header><!-- .entry-header -->
						
							<div class="entry-content">
								
								<?php the_excerpt(); ?>

								<?php
								if ( true === $settings['display_read_more'] ) : ?>
									<a class="btn-read-more" href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>">
										<?php _e('Read more','superclick'); ?>
									</a>
								<?php endif; ?>

							</div><!-- .entry-content -->

						</div>

					</article>

				<?php
				$i++;

			endwhile; ?>

			<?php
			// Remove excerpt filter
			remove_filter( 'excerpt_length', 'tc_magazine_posts_excerpt_length' );
			
		endif;
		
		// Reset Postdata
		wp_reset_postdata();

	} // magazine_posts_right_list()
	
	
	/**
	 * Displays Magazine Posts in Vertical Layout
	 *
	 * @used-by this->render()
	 *
	 * @param array $instance / Settings for this widget instance
	 */
	function magazine_posts_left_list( $settings ) {
		
		// Get latest posts from database
		$query_arguments = array(
			'posts_per_page'		=> (int) $settings['number'],
			'ignore_sticky_posts'	=> true,
			'cat' => (int)$settings['category']
		);
		$posts_query = new WP_Query( $query_arguments );
		$i = 0;

		// Check if there are posts
		if( $posts_query->have_posts() ) :
		
			// Limit the number of words for the excerpt
			add_filter( 'excerpt_length', 'tc_magazine_posts_excerpt_length' );
			
			// Display Posts
			while( $posts_query->have_posts() ) :
				
				$posts_query->the_post(); 
				
				//if( isset($i) and $i == 0 ) : ?>

					<article id="post-<?php the_ID(); ?>" <?php post_class( 'left-post list-post post-item clearfix' ); ?>>

						<div class="post-thumbnail">
							<a href="<?php the_permalink() ?>" rel="bookmark" class="featured-thumbnail">
							
							<?php
							if ( has_post_thumbnail() ) :

								the_post_thumbnail();

							else :
							?>
								
								<img src="<?php echo get_template_directory_uri(); ?>/images/post-thumbnails.jpg" />
							
							<?php
							endif;
							?>

							</a>
						</div><!-- .post-thumbnail -->

						<div class="entry-content">

							<header class="entry-header">
								
								<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
								<?php $this->entry_meta( $settings ); ?>

							</header><!-- .entry-header -->
						
							<div class="entry-content">

								<?php the_excerpt(); ?>

								<?php
								if ( true === $settings['display_read_more'] ) : ?>
									<a class="btn-read-more" href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>">
										<?php _e('Read more','superclick'); ?>
									</a>
								<?php endif; ?>

							</div><!-- .entry-content -->

						</div>

					</article>

				<?php
				//endif; 

				$i++;
				
			endwhile; ?>


			<?php
			// Remove excerpt filter
			remove_filter( 'excerpt_length', 'tc_magazine_posts_excerpt_length' );
			
		endif;
		
		// Reset Postdata
		wp_reset_postdata();

	} // magazine_posts_left_list()

		/**
	 * Displays Magazine Posts in Full Thumbnail Layout
	 *
	 * @used-by this->render()
	 *
	 * @param array $instance / Settings for this widget instance
	 */
	function magazine_posts_full_thubmnail( $settings ) {
		
		// Get latest posts from database
		$query_arguments = array(
			'posts_per_page'		=> (int) $settings['number'],
			'ignore_sticky_posts'	=> true,
			'cat' => (int)$settings['category']
		);
		$posts_query = new WP_Query( $query_arguments );
		$i = 0;

		// Check if there are posts
		if( $posts_query->have_posts() ) :

			// Limit the number of words for the excerpt
			add_filter( 'excerpt_length', 'tc_magazine_posts_excerpt_length' );

			// Display Posts
			while( $posts_query->have_posts() ) :

				$posts_query->the_post(); ?>

					<article id="post-<?php the_ID(); ?>" <?php post_class( 'full-post list-post clearfix' ); ?>>

						<div class="post-thumbnail">
							<a href="<?php the_permalink() ?>" rel="bookmark" class="featured-thumbnail">

								<?php
								if ( has_post_thumbnail() ) :

									the_post_thumbnail( 'superclick-full-thumb' );

								else :
								?>

									<img src="<?php echo get_template_directory_uri(); ?>/images/post-thumbnails.jpg" />
								
								<?php
								endif;
								?>

							</a>
						</div><!-- .post-thumbnail -->

						<div class="entry-content">

							<header class="entry-header">
								
								<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
								<?php $this->entry_meta( $settings ); ?>
					
							</header><!-- .entry-header -->
						
							<div class="entry-content">
								<?php the_excerpt(); ?>
							</div><!-- .entry-content -->

							<?php if ( true === $settings['display_read_more'] ) : ?>
								<a class="btn-read-more" href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php _e('Read More','superclick'); ?></a>
							<?php endif; ?>

						</div>

					</article>

				<?php
				$i++;
				
			endwhile; ?>
		
				
			<?php
			// Remove excerpt filter
			remove_filter( 'excerpt_length', 'tc_magazine_posts_excerpt_length' );
			
		endif;
		
		// Reset Postdata
		wp_reset_postdata();

	} // magazine_posts_left_list()
	
	
	/**
	 * Displays Entry Meta of Posts
	 */
	function entry_meta( $settings ) { 

		$postmeta = '';

		if ( true === $settings['meta_author'] ) {

			$postmeta .= superclick_meta_author();

		}

		if ( true === $settings['meta_date'] ) {

			$postmeta .= superclick_meta_date();

		}

		if ( $postmeta ) {

			echo '<div class="entry-meta">' . $postmeta . '</div>';

		}
	
	} // entry_meta()
	
	
	/**
	 * Displays Widget Title
	 */
	function widget_title( $args, $settings ) {
		
		// Add Widget Title Filter
		$widget_title = apply_filters( 'widget_title', $settings['title'], $settings, $this->id_base );
		
		if( ! empty( $widget_title ) ) :

			// Link Category Title
			if( $settings['category'] > 0 ) : 
			
				// Set Link URL and Title for Category
				$link_title = sprintf( esc_html__( 'View all posts from category %s', 'superclick' ), get_cat_name( $settings['category'] ) );
				$link_url = esc_url( get_category_link( $settings['category'] ) );
				
				// Display Widget Title with link to category archive
				echo '<div class="wrap-header">';
				echo '<h3 class="widget-title"><a class="category-archive-link" href="'. $link_url .'" title="'. $link_title . '">'. $widget_title . '</a></h3>';
				echo '</div>';
			
			else:
				
				// Display default Widget Title without link
				echo $args['before_title'] . $widget_title . $args['after_title']; 
			
			endif;
			
		endif;

	} // widget_title()
	
	
	/**
	 * Update Widget Settings
	 *
	 * @param array $new_instance / New Settings for this widget instance
	 * @param array $old_instance / Old Settings for this widget instance
	 * @return array $instance
	 */
	function update( $new_instance, $old_instance ) {

		$instance = $old_instance;
		$instance['title'] = sanitize_text_field($new_instance['title']);
		$instance['category'] = (int)$new_instance['category'];
		$instance['layout'] = esc_attr($new_instance['layout']);
		$instance['number'] = (int) $new_instance['number'];
		$instance['meta_date'] = !empty($new_instance['meta_date']);
		$instance['meta_author'] = !empty($new_instance['meta_author']);
		$instance['display_read_more'] = !empty($new_instance['display_read_more']);
		
		$this->delete_widget_cache();
		
		return $instance;
	}
	
	
	/**
	 * Displays Widget Settings Form in the Backend
	 *
	 * @param array $instance / Settings for this widget instance
	 */
	function form( $instance ) {
	
		// Get Widget Settings
		$settings = wp_parse_args( $instance, $this->default_settings() );
	
		$gl_1 = isset($settings['layout']) && $settings['layout'] === 'full-thumbnail' ? true : false;
		$gl_2 = isset($settings['layout']) && $settings['layout'] === 'left' ? true : false;
		$gl_3 = isset($settings['layout']) && $settings['layout'] === 'right' ? true : false;

	?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php esc_html_e( 'Title:', 'superclick' ); ?>
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $settings['title']; ?>" />
			</label>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('category'); ?>"><?php esc_html_e( 'Category:', 'superclick' ); ?></label><br/>
			<?php // Display Category Select
				$args = array(
					'show_option_all'    => esc_html__( 'All Categories', 'superclick' ),
					'show_count' 		 => true,
					'hide_empty'		 => false,
					'selected'           => $settings['category'],
					'name'               => $this->get_field_name('category'),
					'id'                 => $this->get_field_id('category')
				);
				wp_dropdown_categories( $args ); 
			?>
		</p>

		<span class="wrap-featured-layout">
			
			<label class="featured-layout-style">
				<input id="<?php echo $this->get_field_id( 'layout' ); ?>" class="radio" type="radio" name="<?php echo $this->get_field_name( 'layout' ); ?>" value="left" <?php checked($gl_2, 1) ?> />
				<img src="<?php echo get_template_directory_uri(); ?>/images/featured-images/list-style-two.png" title="List Style Two" alt="List Style Two" /></br>
			</label>

			<label class="featured-layout-style">
				<input class="radio" type="radio" name="<?php echo $this->get_field_name( 'layout' ); ?>" value="right" <?php checked($gl_3, 1) ?> />
				<img src="<?php echo get_template_directory_uri(); ?>/images/featured-images/list-style-three.png" title="List Style Three" alt="List Style Three" /></br>
			</label>

			<label class="featured-layout-style">
				<input class="radio" type="radio" name="<?php echo $this->get_field_name( 'layout' ); ?>" value="full-thumbnail" <?php checked($gl_1, 1) ?> />
				<img src="<?php echo get_template_directory_uri(); ?>/images/featured-images/list-style-one.png" title="List Style One" alt="List Style One" /></br>
			</label>

		</span>
		
		<p>
			<label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php esc_html_e( 'Number of posts:', 'superclick' ); ?>
				<input id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" type="text" value="<?php echo (int) $settings['number']; ?>" size="3" />
			</label>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'meta_date' ); ?>">
				<input class="checkbox" type="checkbox" <?php checked( $settings['meta_date'] ) ; ?> id="<?php echo $this->get_field_id( 'meta_date' ); ?>" name="<?php echo $this->get_field_name( 'meta_date' ); ?>" />
				<?php esc_html_e( 'Display post date', 'superclick' ); ?>
			</label>
		</p>
		
		<p>
			<label for="<?php echo $this->get_field_id( 'meta_author' ); ?>">
				<input class="checkbox" type="checkbox" <?php checked( $settings['meta_author'] ) ; ?> id="<?php echo $this->get_field_id( 'meta_author' ); ?>" name="<?php echo $this->get_field_name( 'meta_author' ); ?>" />
				<?php esc_html_e( 'Display post author', 'superclick' ); ?>
			</label>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'display_read_more' ); ?>">
				<input class="checkbox" type="checkbox" <?php checked( $settings['display_read_more'] ) ; ?> id="<?php echo $this->get_field_id( 'display_read_more' ); ?>" name="<?php echo $this->get_field_name( 'display_read_more' ); ?>" />
				<?php esc_html_e( 'Display read more', 'superclick' ); ?>
			</label>
		</p>

<?php
	} // form()
	
	
	/**
	 * Delete Widget Cache
	 */
	public function delete_widget_cache() {
		
		wp_cache_delete( 'widget_tc_magazine_posts_lists', 'widget' );
		
	}
	
}

// Register Widget
add_action( 'widgets_init', 'tc_register_magazine_posts_lists_widget' );

function tc_register_magazine_posts_lists_widget() {

	register_widget( 'tc_Magazine_Posts_Lists_Widget' );
	
}