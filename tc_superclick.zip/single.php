<?php
/**
 * The template for displaying all single posts.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Superclick
 */

$theme_options = superclick_theme_options();
$position = array_flip($theme_options['sharing_button_position']);
get_header();

	if ( isset( $position['sticky-left'] ) && $theme_options['social_sharing_button'] == 1  ) :
	?>

		<!-- loating-to-right sharing-top-float -->
		<div class="sticky-social">
			
			<?php
				superclick_social_icons('social-sharing-left sticky-left')
			?>
			
			<span class="btn-hide">
				<i class="fa fa-mail-reply-all"></i>
			</span>
		
		</div>

	<?php
	endif;
	?>

	<?php
	if ( $theme_options['sidebar_layout'] != 'no-sidebar' ) {

		get_sidebar( 'left' );

	}
	?>

	<div id="primary" class="content-area col-xs-12 col-sm-8 col-md-7 col-lg-7">

		<main id="main" class="site-main" role="main">

		<?php
		while ( have_posts() ) : the_post();

			get_template_part( 'template-parts/content', 'single' );

		?>

		<?php
		// Posts Nevigation
		if ( $theme_options['post_nav'] == 1 ) :

			superclick_post_nav();

		endif;
		?>

		<?php
		// Related Posts
		if ( $theme_options['related_posts'] == 1 ) :

			superclick_related_posts();

		endif;
		?>

		<?php if ( $theme_options['author_bio'] == 1 ) : ?>
		
			<div class="author-bio">

				<h3 class="title-bio">About Author</h3>

				<div class="wrap-bio">
					<div class="bio-avatar"><?php echo get_avatar(get_the_author_meta('user_email'),'100'); ?></div>
					<p class="bio-name"><?php _e('About Author:', 'superclick') ?> <?php the_author_posts_link(); ?></p>
					<p class="bio-desc"><?php the_author_meta('description'); ?></p>
				</div>

			</div>

		<?php endif; ?>

		<?php

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :

				comments_template();

			endif;

		endwhile; // End of the loop.
		?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
if ( $theme_options['sidebar_layout'] != 'no-sidebar' ) {

	get_sidebar();

}
get_footer();