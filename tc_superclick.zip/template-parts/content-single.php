<?php
/**
 * Template part for displaying content single.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Mekanews
 */
$theme_options = superclick_theme_options();
$position = array_flip($theme_options['sharing_button_position']);
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	
	<?php if ( $theme_options['breadscrumb'] == 1 ) : ?>

		<div class="breadcrumb">
			
			<?php echo superclick_custom_breadcrumb(); ?>

		</div>
		
	<?php endif; ?>

	<?php if ( $theme_options['featured_post_single_page'] == 1 ) : ?>
		
		<div class="post-thumbnail">
			
			<?php if ( has_post_thumbnail() ) : ?>
				
				<?php the_post_thumbnail('featured-post-thumbnails'); ?>
			
			<?php else : ?>
				
				<img src="<?php echo get_template_directory_uri(); ?>/images/featured-post-thumbnails.jpg" />
			
			<?php endif; ?>

		</div><!-- .post-thumbnail -->

	<?php endif; ?>

	<header class="entry-header">
		
		<?php
		the_title( '<h1 class="entry-title single-title">', '</h1>' );

		if ( 'post' === get_post_type() ) :
			
			$meta_items = array_flip( $theme_options['post_meta_info'] );	
			
			if ( 'post' === get_post_type() ) {

				superclick_entry_meta();

			}

			if ( isset( $position['before-content'] ) ) {
				
				superclick_social_icons('social-sharing-top');

			}
		endif;
		?>

	</header><!-- .entry-header -->

	<div class="entry-content">
		<?php

			the_content( sprintf(

				wp_kses( __( 'Continue reading %s <span class="meta-nav">&rarr;</span>', 'superclick' ), array( 'span' => array( 'class' => array() ) ) ),
				the_title( '<span class="screen-reader-text">"', '"</span>', false )
			
			) );

			wp_link_pages( array(

				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'superclick' ),
				'after'  => '</div>',

			) );

		?>
		
		<?php
			if ( isset( $position['after-content'] ) ) {
				
				superclick_social_icons('after-content');

			}
		?>
	
	</div><!-- .entry-content -->

</article><!-- #post-## -->